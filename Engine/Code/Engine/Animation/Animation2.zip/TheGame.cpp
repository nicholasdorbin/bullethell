#include "Game/TheGame.hpp"
#include "Engine/Renderer/Renderer.hpp"
#include "Game/TheApp.hpp"
//#include "Game/GameCommon.hpp"
#include "Engine/Math/AABB3.hpp"

#include <time.h>
#include "Engine/Core/Time.hpp"
#include "Engine/Core/Console.hpp"
#include "Engine/Core/StringUtils.hpp"
#include "Engine/Core/EngineCommon.hpp"

#include "Engine/Renderer/Shaders/GPUProgram.hpp"
#include "Engine/Renderer/Shaders/Mesh.hpp"
#include "Engine/Renderer/Shaders/MeshBuilder.hpp"
#include "Engine/Renderer/Shaders/Material.hpp"
#include "Engine/Core/Camera3D.hpp"
#include "Engine/Renderer/Shaders/Light.hpp"
#include "Engine/Tools/fbx.hpp"
#include "Engine/Renderer/Skeleton.hpp"
#include "Engine/Animation/Motion.hpp"

TheGame* g_theGame = nullptr;


const float XHAIR_LENGTH = 15.f;
const std::string FONT_NAME = "Data/Fonts/ArialFont.fnt";
//const IntVector2 snapBackPos = IntVector2(800, 450);

const std::string TEST_FILE = "Data/Images/Test_StbiAndDirectX.png";


CONSOLE_COMMAND(fbx_list)
{
	if (args.m_argList.size() < 1) //Because I'm lazy
	{
		std::string filename = "Data/Models/SampleBox.fbx";
		FbxListScene(filename);
	}
	else
	{
		std::string filename = args.m_argList[0];
		FbxListScene(filename);
	}
		//return;
	

}

CONSOLE_COMMAND(fbx_load)
{
	if (args.m_argList.size() < 1) //Because I'm lazy
	{
		g_theGame->ClearBuilderPointers(g_theGame->m_modelMeshBuilder, g_theGame->m_modelRenderer, g_theGame->m_modelMesh);
	

		std::string filename = "Data/Models/UnityChan/UnityChan/Animations/unitychan_WALK00_F.fbx";
		std::vector<MeshBuilder*> importMeshes;
		SceneImport* thisScene = FbxLoadSceneFromFile(filename, g_engineBasis, true, mat44_fl::identity);
		importMeshes = thisScene->meshes;
		//#TODO Make this NOT new off a MeshBuilder. Or at least deconstruct it.
		std::vector< Skeleton* > importSkeletons;
		std::vector<Motion*> importMotions;
		importSkeletons = thisScene->skeletons;
		importMotions = thisScene->motions;
		if (importSkeletons.size() > 0)
		{
			g_theGame->m_skeleton = importSkeletons[0];
			g_theGame->PopulateJointMeshRenderer(importSkeletons[0]);
		}
		if (importMotions.size() > 0)
		{
			g_theGame->m_motions = importMotions;
		}
		g_theGame->m_modelMeshBuilder = new MeshBuilder(importMeshes);
	}
	else if (args.m_argList.size() == 1)
	{
		g_theGame->ClearBuilderPointers(g_theGame->m_modelMeshBuilder, g_theGame->m_modelRenderer, g_theGame->m_modelMesh);

		std::string filename = "Data/Models/" + args.m_argList[0];
		std::vector<MeshBuilder*> importMeshes;
		SceneImport* thisScene = FbxLoadSceneFromFile(filename, g_engineBasis, true, mat44_fl::identity);
		importMeshes = thisScene->meshes;
		//#TODO Make this NOT new off a MeshBuilder. Or at least deconstruct it.
		std::vector< Skeleton* > importSkeletons;
		std::vector<Motion*> importMotions;
		importSkeletons = thisScene->skeletons;
		importMotions = thisScene->motions;
		g_theGame->m_modelMeshBuilder = new MeshBuilder(importMeshes);
		if (importSkeletons.size() == 1)
		{
			g_theGame->m_skeleton = importSkeletons[0];
			g_theGame->PopulateJointMeshRenderer(importSkeletons[0]);
		}
		if (importMotions.size() > 0)
		{
			g_theGame->m_motions = importMotions;
		}
		
	}
	else if (args.m_argList.size() == 2)
	{
		g_theGame->ClearBuilderPointers(g_theGame->m_modelMeshBuilder, g_theGame->m_modelRenderer, g_theGame->m_modelMesh);

		std::string filename = "Data/Models/" + args.m_argList[0];
		float scale = stof(args.m_argList[1]);
		mat44_fl transform = mat44_fl::identity;
		MatrixMakeScale(&transform, scale);
		std::vector<MeshBuilder*> importMeshes;
		SceneImport* thisScene = FbxLoadSceneFromFile(filename, g_engineBasis, true, transform);
		importMeshes = thisScene->meshes;
		std::vector<Skeleton*> importSkeletons = thisScene->skeletons;
		std::vector<Motion*> importMotions;
		importMotions = thisScene->motions;

		if (importSkeletons.size() == 1)
		{
			g_theGame->m_skeleton = importSkeletons[0];
			g_theGame->PopulateJointMeshRenderer(importSkeletons[0]);
		}

		if (importMotions.size() > 0)
		{
			g_theGame->m_motions = importMotions;
		}
		g_theGame->m_modelMeshBuilder = new MeshBuilder(importMeshes);
	}
	//return;


}

CONSOLE_COMMAND(mesh_save)
{
	if (g_theGame->m_modelMeshBuilder == nullptr)
	{
		return;
	}

	if (args.m_argList.size() < 1) //Because I'm lazy
	{
		std::string filename = "Data/Models/basicbox.mesh";
		g_theGame->m_modelMeshBuilder->WriteToFile(filename);
	}
	else
	{
		std::string filename = "Data/Models/" + args.m_argList[0];
		g_theGame->m_modelMeshBuilder->WriteToFile(filename);
	}
	//return;
}

CONSOLE_COMMAND(mesh_load)
{
  
	if (args.m_argList.size() < 1) //Because I'm lazy
	{
		g_theGame->ClearBuilderPointers(g_theGame->m_modelMeshBuilder, g_theGame->m_modelRenderer, g_theGame->m_modelMesh);
		g_theGame->m_modelMeshBuilder = new MeshBuilder();
		std::string filename = "Data/Models/basicbox.mesh";
		g_theGame->m_modelMeshBuilder->LoadFromFile(filename);
	}
	else
	{
		g_theGame->ClearBuilderPointers(g_theGame->m_modelMeshBuilder, g_theGame->m_modelRenderer, g_theGame->m_modelMesh);
		g_theGame->m_modelMeshBuilder = new MeshBuilder();
		std::string filename = "Data/Models/" + args.m_argList[0];
		g_theGame->m_modelMeshBuilder->LoadFromFile(filename);
	}
	//return;
}

CONSOLE_COMMAND(skel_save)
{
	if (g_theGame->m_skeleton == nullptr)
	{
		return;
	}

	if (args.m_argList.size() < 1) //Because I'm lazy
	{
		std::string filename = "Data/Models/basicbox.skel";
		g_theGame->m_skeleton->WriteToFile(filename);
	}
	else
	{
		std::string filename = "Data/Models/" + args.m_argList[0];
		g_theGame->m_skeleton->WriteToFile(filename);
	}
	//return;
}

CONSOLE_COMMAND(skel_load)
{

	if (args.m_argList.size() < 1) //Because I'm lazy
	{
		delete g_theGame->m_skeleton;
		g_theGame->m_skeleton = nullptr;
		g_theGame->m_skeleton = new Skeleton();
		std::string filename = "Data/Models/basicbox.skel";
		g_theGame->m_skeleton->LoadFromFile(filename);
		g_theGame->PopulateJointMeshRenderer(g_theGame->m_skeleton);
	}
	else
	{
		if (g_theGame->m_skeleton)
		{
			delete g_theGame->m_skeleton;
			g_theGame->m_skeleton = nullptr;
		}
		
		g_theGame->m_skeleton = new Skeleton();
		std::string filename = "Data/Models/" + args.m_argList[0];
		g_theGame->m_skeleton->LoadFromFile(filename);
		g_theGame->PopulateJointMeshRenderer(g_theGame->m_skeleton);
	}
	//return;
}

CONSOLE_COMMAND(motion_save)
{
	if (g_theGame->m_motions.size() == 0 || g_theGame->m_motions.size() <= g_theGame->m_motionIndex)
	{
		return;
	}

	if (args.m_argList.size() < 1) //Because I'm lazy
	{
		std::string filename = "Data/Models/basicmotion.anim";
		g_theGame->m_motions[g_theGame->m_motionIndex]->WriteToFile(filename);
	}
	else
	{
		std::string filename = "Data/Models/" + args.m_argList[0];
		g_theGame->m_motions[g_theGame->m_motionIndex]->WriteToFile(filename);
	}

}

CONSOLE_COMMAND(motion_load)
{
	if (args.m_argList.size() < 1) //Because I'm lazy
	{
		Motion* newMotion = new Motion();
		std::string filename = "Data/Models/basicmotion.anim";
		newMotion->LoadFromFile(filename);
		g_theGame->m_motions.push_back(newMotion);
		g_theGame->m_motionIndex = g_theGame->m_motions.size() - 1;
	}
	else
	{

		Motion* newMotion = new Motion();
		std::string filename = "Data/Models/" + args.m_argList[0];
		newMotion->LoadFromFile(filename);
		g_theGame->m_motions.push_back(newMotion);
		g_theGame->m_motionIndex = g_theGame->m_motions.size() - 1;
	}
}


CONSOLE_COMMAND(toggle_skeleton)
{
	g_theGame->m_showSkeleton = !g_theGame->m_showSkeleton;
}

CONSOLE_COMMAND(toggle_model)
{
	g_theGame->m_showModelMesh = !g_theGame->m_showModelMesh;
}

CONSOLE_COMMAND(set_motion_index)
{
	if(args.m_argList.size() < 2)
		g_theGame->m_motionIndex = stoi(args.m_argList[0]);
}

TheGame::TheGame()
	: m_lightNum(2)
	, m_maxLights(16)
	, m_modelRenderState(0)
	, m_showSkeleton(true)
	, m_showModelMesh(false)
	, m_motionTime(0.f)
	, m_motionIndex(0)
	, m_playAnimation(true)
{
	//InitializeCommon();
	m_modelMeshBuilder = nullptr;
	m_modelRenderer = nullptr;
	m_modelMesh = nullptr;
	m_skeleton = nullptr;
	
	m_world = new World();
// 	g_theRenderer->AddDebugPoint(Vector3(2.f, 0.f, 1.f), Rgba::RED, 10.f, RenderCommand::DEPTH_TEST_ON);
// 	g_theRenderer->AddDebugLine(Vector3(1.f, 1.f, 1.f), Vector3(10.f, 2.f, 5.f), Rgba::RED, -1.f, RenderCommand::DEPTH_TEST_ON);
// 	g_theRenderer->AddDebugArrow(Vector3(1.f, 1.f, 1.f), Vector3(10.f, 10.f, 10.f), Rgba::BLUE, 7.f, RenderCommand::DEPTH_TEST_OFF);
// 
// 	g_theRenderer->AddDebugAABB3(Vector3(1.f, 1.f, 1.f), Vector3(4.f, 4.f, 4.f), Rgba::BLACK, -1.f, RenderCommand::DEPTH_TEST_ON);
// 	g_theRenderer->AddDebugSphere(Vector3(3.f, 3.f, 3.f), 1.f, Rgba::PINK, -1.f, RenderCommand::XRAY);

	Console::RegisterCommand("draw", DrawDebugArrow );


	MeshBuilder meshBuilder = MeshBuilder(true);
	meshBuilder.AddCustom(Vector3(0.f, 0.f, 0.f), Vector3(1.f, 0.f, 0.f), Vector3(0.f, 1.f, 0.f), -20.f, 20.f, 50, -20.f, 20.f, 50);
	//meshBuilder.AddTriangle(Vector3(0.f, 0.f, 2.f), Vector3(0.f, 0.f, 0.f), Vector3(2.f, 0.f, 0.f));
//	MeshBuildFace(m_meshBuilder, Vector3::ZERO, Vector3(0.f, 0.f, 2.f), Vector3(2.f, 0.f, 0.f));

	m_cubeMesh =  Mesh::GetMeshShape(MeshShape_CUBE);
	m_sphereMesh =  Mesh::GetMeshShape(MeshShape_SPHERE);
	m_planeMesh = new Mesh(&meshBuilder, VertexType_PCUTB);
	m_programDot3 = new GPUProgram("Data/Shaders/multi_light.vert", "Data/Shaders/multilight_rendermode.frag");

	m_materialStone = new Material(m_programDot3);
	//m_cubeMeshRenderer.push_back(new MeshRenderer(m_cubeMesh, m_materialStone, Transform(Vector3(0.f, 0.f, 0.0f), mat44_fl::identity, Vector3::ONE)));
// 	m_cubeMeshRenderer.push_back(new MeshRenderer(m_cubeMesh, m_materialStone, Transform(Vector3(0.f, 0.f, 2.0f), mat44_fl::identity, Vector3::ONE)));

	//m_cubeMeshRenderer.push_back(new MeshRenderer(m_planeMesh, m_materialStone, Transform(Vector3(0.f, 0.f, 0.0f), mat44_fl::identity, Vector3::ONE)));

	for (int lightCount = 0; lightCount < m_maxLights; ++lightCount)
	{
		m_lightMeshRenderer.push_back(new MeshRenderer(m_sphereMesh, m_materialStone, Transform(Vector3::ZERO, mat44_fl::identity, Vector3(0.1f))));
	}
	
	m_materialStone->SetUniform("gDiffuseTex", "Data/Images/white.png");
	m_materialStone->SetUniform("gNormalTex", "Data/Images/blue.png");
	m_materialStone->SetUniform("gSpecularTex", "Data/Images/black.png");
	m_materialStone->SetUniform("gEmissiveTex", "Data/Images/black.png");
	
	m_materialStone->SetUniform("gSpecularPower", 2.f);
	m_materialStone->SetUniform("gSpecularIntensity", 0.4f);
	m_materialStone->SetUniform("gAmbientLight", Rgba(0, 255, 0, 10));

	m_materialStone->SetUniform("gFogColor", Vector3(0.2f,0.2f,0.2f));
	m_materialStone->SetUniform("gFogNear", 50.f);
	m_materialStone->SetUniform("gFogFar", 55.f);//gFogNearFactor, gFogFarFactor
	m_materialStone->SetUniform("gFogNearFactor", 0.f);
	m_materialStone->SetUniform("gFogFarFactor", 1.f);
	
	//m_lights.push_back(Light(Rgba::WHITE.FloatRepresentation(), Vector3::ZERO, 1.f));
	m_lights.push_back(Light(Rgba::WHITE.FloatRepresentation(), Vector3::ZERO, 2.f));
	m_lights.push_back(Light(Rgba::WHITE.FloatRepresentation(), Vector3::ZERO, Vector3(0.f,0.f,-.2f),
		1.f, 6.f, 1.f, 1.f,
		1.f,
		1.f, -1.f, 1.f, 1.f));
	//m_lights.push_back((Light(Rgba::BLUE.FloatRepresentation(), Vector3::ZERO, Vector3::ZERO, 1.f, 1.f, 1.f, 1.f, 1.f, 1.f, -1.f, 1.f, 1.f)));
	m_lights.push_back(Light(Rgba::WHITE.FloatRepresentation(), Vector3::ZERO, 1.f));
	m_lights.push_back(Light(Rgba::YELLOW.FloatRepresentation(),Vector3::ZERO, 1.f));
	m_lights.push_back(Light(Rgba::WHITE.FloatRepresentation(), Vector3::ZERO, 1.f));
	m_lights.push_back(Light(Rgba::GREEN.FloatRepresentation(), Vector3::ZERO, 1.f));
	m_lights.push_back(Light(Rgba::WHITE.FloatRepresentation(), Vector3::ZERO, 1.f));
	m_lights.push_back(Light(Rgba::WHITE.FloatRepresentation(), Vector3::ZERO, 1.f));
	m_lights.push_back(Light(Rgba::WHITE.FloatRepresentation(), Vector3::ZERO, 1.f));
	m_lights.push_back(Light(Rgba::BLUE.FloatRepresentation(), Vector3::ZERO, 1.f));
	m_lights.push_back(Light(Rgba::WHITE.FloatRepresentation(), Vector3::ZERO, 1.f));
	m_lights.push_back(Light(Rgba::WHITE.FloatRepresentation(), Vector3::ZERO, 1.f));
	m_lights.push_back(Light(Rgba::WHITE.FloatRepresentation(), Vector3::ZERO, 1.f));
	m_lights.push_back(Light(Rgba::PINK.FloatRepresentation(), Vector3::ZERO, 1.f));
	m_lights.push_back(Light(Rgba::WHITE.FloatRepresentation(), Vector3::ZERO, 1.f));
	m_lights.push_back(Light(Rgba::WHITE.FloatRepresentation(), Vector3::ZERO, 1.f));

	//Color the mesh
	/*
	m_lightMeshRenderer[0]->SetUniform("gColor", Rgba::WHITE);
	m_lightMeshRenderer[1]->SetUniform("gColor", Rgba::RED);
	m_lightMeshRenderer[2]->SetUniform("gColor", Rgba::WHITE);
	m_lightMeshRenderer[3]->SetUniform("gColor", Rgba::YELLOW);
	m_lightMeshRenderer[4]->SetUniform("gColor", Rgba::WHITE);
	m_lightMeshRenderer[5]->SetUniform("gColor", Rgba::GREEN);
	m_lightMeshRenderer[6]->SetUniform("gColor", Rgba::WHITE);
	m_lightMeshRenderer[7]->SetUniform("gColor", Rgba::WHITE);
	m_lightMeshRenderer[8]->SetUniform("gColor", Rgba::WHITE);
	m_lightMeshRenderer[9]->SetUniform("gColor", Rgba::BLUE);
	m_lightMeshRenderer[10]->SetUniform("gColor", Rgba::WHITE);
	m_lightMeshRenderer[11]->SetUniform("gColor", Rgba::WHITE);
	m_lightMeshRenderer[12]->SetUniform("gColor", Rgba::WHITE);
	m_lightMeshRenderer[13]->SetUniform("gColor", Rgba::PINK);
	m_lightMeshRenderer[14]->SetUniform("gColor", Rgba::WHITE);
	m_lightMeshRenderer[15]->SetUniform("gColor", Rgba::WHITE);
	*/

	//Setting Light Intensity
	unsigned char lightIntensity = 100;
	//unsigned char lightIntensity = 30;
	for (int lightIndex = 0; lightIndex < m_maxLights; ++lightIndex)
	{
		m_lights[lightIndex].m_color.w = lightIntensity;
	}

}

void TheGame::SetUpPerspectiveProjection() const
{
	float aspect = (16.f / 9.f);
	//float fovDegreesHorizontal = 90.f;
	float fovDegreesVertical = 70.f;
	float zNear = 0.1f;
	float zFar = 100.f;

	g_theRenderer->SetPerspective(fovDegreesVertical, aspect, zNear, zFar);
}

void TheGame::Update(const float deltaSeconds)
{
	if (g_theApp->m_inputSystem.IsKeyJustPressed(0xc0) && g_theApp->m_inputSystem.IsKeyDown(0xc0)) //why tho ~
	{
		g_theConsole->m_isOpen = !g_theConsole->m_isOpen;
	}
	if (!g_theConsole->m_isOpen)
	{
		m_world->Update(deltaSeconds);
	
		if (g_theApp->m_inputSystem.IsKeyPressed('U'))
		{
			if (g_theGame->m_modelMeshBuilder)
				g_theGame->m_modelMeshBuilder->MeshReduce();
		}

		if (g_theApp->m_inputSystem.IsKeyPressed('M'))
		{
			g_theGame->m_showSkeleton = !g_theGame->m_showSkeleton;
		}
		if (g_theApp->m_inputSystem.IsKeyPressed('N'))
		{
			g_theGame->m_showModelMesh = !g_theGame->m_showModelMesh;
		}

		//Lights
		if (g_theApp->m_inputSystem.IsKeyJustPressed('1'))
		{
			MeshBuilder planeBuilder = MeshBuilder(true);
			planeBuilder.AddPlane(Vector3(0.f, 0.f, 0.f), Vector3(1.f, 0.f, 0.f), Vector3(0.f, 1.f, 0.f), -20.f, 20.f, 50, -20.f, 20.f, 50);
			m_planeMesh->Update(&planeBuilder, VertexType_PCUTB);
			
		}
		else if (g_theApp->m_inputSystem.IsKeyJustPressed('2'))
		{
			MeshBuilder planeBuilder = MeshBuilder(true);
			planeBuilder.AddCustom(Vector3(0.f, 0.f, 0.f), Vector3(1.f, 0.f, 0.f), Vector3(0.f, 1.f, 0.f), -20.f, 20.f, 50, -20.f, 20.f, 50);
			m_planeMesh->Update(&planeBuilder, VertexType_PCUTB);
		}
		else if (g_theApp->m_inputSystem.IsKeyJustPressed('3'))
		{
			MeshBuilder planeBuilder = MeshBuilder(true);
			planeBuilder.AddPlane(Vector3(0.f, 0.f, 0.f), Vector3(1.f, 0.f, 0.f), Vector3(0.f, 1.f, 1.f), -20.f, 20.f, 50, -20.f, 20.f, 50);
			m_planeMesh->Update(&planeBuilder, VertexType_PCUTB);
		}
		else if (g_theApp->m_inputSystem.IsKeyJustPressed('4'))
		{
			MeshBuilder planeBuilder = MeshBuilder(true);
			planeBuilder.AddCustom(Vector3(0.f, 0.f, 0.f), Vector3(1.f, 0.f, 0.f), Vector3(0.f, 1.f, 1.f), -20.f, 20.f, 50, -20.f, 20.f, 50);
			m_planeMesh->Update(&planeBuilder, VertexType_PCUTB);
		}
		

		//FBO
		if (g_theApp->m_inputSystem.IsKeyJustPressed(VK_NUMPAD0))
		{
			m_modelRenderState = 0;
		}
		else if (g_theApp->m_inputSystem.IsKeyJustPressed(VK_NUMPAD1))
		{
			m_modelRenderState = 1;
		}
		else if (g_theApp->m_inputSystem.IsKeyJustPressed(VK_NUMPAD2))
		{
			m_modelRenderState = 2;
		}
		else if (g_theApp->m_inputSystem.IsKeyJustPressed(VK_NUMPAD3))
		{
			m_modelRenderState = 3;
		}
		
		if (g_theApp->m_inputSystem.IsKeyPressed(VK_ADD))
		{
			if (m_motions.size() > m_motionIndex && m_motions[m_motionIndex])
			{
				m_motions[m_motionIndex]->Reset();
			}
		}

		if (g_theApp->m_inputSystem.IsKeyPressed(VK_DIVIDE))
		{
			if (m_motions.size() > m_motionIndex && m_motions[m_motionIndex])
			{
				m_motions[m_motionIndex]->m_wrapMode = WRAPMODE_CLAMP;
			}
		}

		if (g_theApp->m_inputSystem.IsKeyPressed(VK_MULTIPLY))
		{
			if (m_motions.size() > m_motionIndex && m_motions[m_motionIndex])
			{
				m_motions[m_motionIndex]->m_wrapMode = WRAPMODE_LOOP;
			}
		}
		if (g_theApp->m_inputSystem.IsKeyPressed(VK_SUBTRACT))
		{
			if (m_motions.size() > m_motionIndex && m_motions[m_motionIndex])
			{
				m_motions[m_motionIndex]->m_wrapMode = WRAPMODE_PINGPONG;
			}
		}

		if (g_theApp->m_inputSystem.IsKeyPressed('O'))
		{
			g_debugDrawing = !g_debugDrawing;
		}

		if (g_theApp->m_inputSystem.IsKeyPressed('P'))
		{
			m_playAnimation = !m_playAnimation;
		}
	}
	else
	{
		g_theConsole->Update(deltaSeconds);
	}
	
	
	static float m_age;
	m_age += deltaSeconds;

	if (m_playAnimation)
	{
		m_motionTime += deltaSeconds;
	}
	if (m_motions.size() > m_motionIndex && m_motions[m_motionIndex])
	{
		if (m_motionTime > m_motions[m_motionIndex]->m_totalLengthSeconds)
			m_motionTime = 0.f;
	}
	

	//Lights
	for (int lightCount = 0; lightCount < m_maxLights; ++lightCount)
	{
		float time = m_age * 50.f;
		float offset = (360.f / 16.f) * (float)lightCount;
		float radius = 0.5f * SinDegrees(time*0.9f) + 10.5f;
		float xPos = radius*CosDegrees(time + offset);
		float yPos = radius*SinDegrees(time + offset);

		if (lightCount == 0)
		{
// 			m_lights[0] = Light(Rgba::WHITE.FloatRepresentation(), g_camera.m_position, g_camera.GetForwardXYZ().GetNormalized(),
// 				1.f, 6.f, 1.f, 0.f,
// 				0.f,
// 				CosDegrees(5.f), CosDegrees(15.f), 1.f, 0.f);
			m_lights[lightCount].m_position = g_camera.m_position;
			//m_lights[lightCount].m_direction = g_camera.GetForwardXYZ().GetNormalized();
		}
		else
		{
			//m_lights[lightCount].m_position = Vector3(xPos, yPos, 2.f);
		}

		//m_lights[lightCount].m_position = Vector3(xPos, yPos, 0.f);
		//m_lights[lightCount].m_position = g_camera.m_position;
	}

	for (int cubeIndex = 0; cubeIndex < (int)m_cubeMeshRenderer.size(); ++cubeIndex)
	{
		m_cubeMeshRenderer[cubeIndex]->SetUniform(m_lights, m_lightNum);
		m_cubeMeshRenderer[cubeIndex]->SetUniform("gCameraPosition", g_camera.m_position);
		m_cubeMeshRenderer[cubeIndex]->SetUniform("gAge", abs(cos(m_age)));
		m_cubeMeshRenderer[cubeIndex]->Update();
	}

	//Update Light positions
	for (int lightCount = 0; lightCount < m_maxLights; ++lightCount)
	{
		m_lightMeshRenderer[lightCount]->SetPosition(m_lights[lightCount].m_position);
		//m_lightMeshRenderer[lightCount]->SetPosition(g_camera.m_position);
		m_lightMeshRenderer[lightCount]->Update();
	}

	if (m_playAnimation)
	{
		if (m_motions.size() > 0 && m_skeleton)
		{
			if (m_motionIndex < m_motions.size())
				m_motions[m_motionIndex]->Update(m_skeleton, deltaSeconds);
		}
	}
	

	if (m_modelMeshBuilder && m_modelRenderer == nullptr)
	{
		m_modelMesh = new Mesh(m_modelMeshBuilder, VertexType_PCUTB);
		m_modelRenderer = new MeshRenderer(m_modelMesh, m_materialStone, Transform(Vector3::ZERO, mat44_fl::identity, Vector3(1.f)));
	}

	if (m_modelMeshBuilder && m_modelRenderer)
	{
		m_modelRenderer->SetUniform(m_lights, m_lightNum);
		m_modelRenderer->SetUniform("gCameraPosition", g_camera.m_position);
		m_modelRenderer->SetUniform("gAge", abs(cos(m_age)));
		m_modelRenderer->SetUniform("gRenderState", m_modelRenderState);

		m_modelRenderer->Update();
	}
	g_theApp->m_inputSystem.UpdateKeyJustPressedState();
	g_theConsole->m_inputSystem.UpdateKeyJustPressedState();
	g_theRenderer->UpdateRenderCommands(deltaSeconds);
}

void TheGame::Render(const float deltaSeconds) const
{

	//g_theRenderer->ClearScreenDepth(0.5f, 0.85f, 0.9f);
	
	//g_theRenderer->FramebufferBind(g_theApp->m_fbo);
	
	//g_theRenderer->ClearScreenDepth(0.5f, 0.85f, 0.9f);
	SetUpPerspectiveProjection();
	g_theRenderer->RotateView(-90.f, 1.f, 0.f, 0.f);

	g_theRenderer->RotateView(-g_camera.m_orientation.m_pitchDegreesAboutX, 1.f, 0.f, 0.f);
	g_theRenderer->RotateView(g_camera.m_orientation.m_yawDegreesAboutZ, 0.f, 0.f, 1.f);
	g_theRenderer->TranslateView(-g_camera.m_position);


	m_world->Render();
   

	//g_theRenderer->DrawGrid(200, 200);
	g_theRenderer->HandleRenderCommands();
	
	//g_theRenderer->DrawSphere(Vector3(1.f, 1.f, 1.f), 4.f);
	g_theRenderer->SetColor(1.f, 1.f, 1.f, 1.f);
	static BitmapFontMeta* bitmapFont = BitmapFontMeta::CreateOrGetFont(FONT_NAME);
	//g_theRenderer->DrawTextMeta2D(Vector3(8.f, 2.f, 15.f), 0.02f, "Krunk ain't dead.", Rgba::WHITE, bitmapFont, Vector3(1.f,0.f,0.f), Vector3(0.f, 0.f,-1.f));
	static float m_age;
	m_age += deltaSeconds;
	std::string cameraPosText = Stringf("Camera: %.1f,%.1f,%.1f", g_camera.m_position.x, g_camera.m_position.y, g_camera.m_position.z );
	std::string cameraAngleText = Stringf("Camera: %.1f,%.1f,%.1f", g_camera.m_orientation.m_pitchDegreesAboutX, g_camera.m_orientation.m_rollDegreesAboutY,
		g_camera.m_orientation.m_yawDegreesAboutZ);
	std::string meshText = "";
	if (g_theGame->m_modelMeshBuilder)
		 meshText = Stringf("Verts: %i",g_theGame->m_modelMeshBuilder->GetVertexData().size());


	//g_theRenderer->RenderStep(deltaSeconds);
	//Draw Cubes
	g_theRenderer->SetCullFace(true);
	g_theRenderer->SetDepthTest(true);
	for (int cubeIndex = 0; cubeIndex < (int)m_cubeMeshRenderer.size(); ++cubeIndex)
	{
		g_theRenderer->MeshRender(m_cubeMeshRenderer[cubeIndex], &g_camera);
	}


	//Draw Lights
	for (int lightCount = 1; lightCount < m_lightNum; ++lightCount)
	{
		//g_theRenderer->MeshRender(m_lightMeshRenderer[lightCount], &g_camera);
		g_theRenderer->DrawSphere(m_lights[lightCount].m_position, 1.f);
	}
	if (m_modelRenderer && m_showModelMesh)
	{
		g_theRenderer->MeshRender(m_modelRenderer, &g_camera);
	}
	//m_modelRenderer->Update();
	if (g_debugDrawing)
	{
		g_theRenderer->DrawAxes();
	}


	if (m_skeleton && m_showSkeleton)
	{
		for (unsigned int jointIndex = 0; jointIndex < m_jointMeshRenderer.size(); ++jointIndex)
		{
			g_theRenderer->SetDepthTest(false);
			//g_theRenderer->MeshRender(m_jointMeshRenderer[jointIndex], &g_camera);
			g_theRenderer->DrawSphere(m_skeleton->GetJointPosition(jointIndex), 0.05f);
			m_skeleton->RenderBones();
		}
	}




	g_theRenderer->SetOrtho(Vector2(0.f, 1600.f), Vector2(0.f, 900.f));
	g_theRenderer->SetDepthTest(false);

	float motionTime = 0.f;
	if (m_motions.size() > m_motionIndex && m_motions[m_motionIndex])
	{
		motionTime = m_motions[m_motionIndex]->m_currentTime;
	}
	std::string motionTimeText = Stringf("Motion: %f", motionTime);
	g_theRenderer->DrawTextMeta2D(Vector3(50.f,120.f,0.f),0.5f, cameraPosText, Rgba::WHITE, bitmapFont);
	g_theRenderer->DrawTextMeta2D(Vector3(50.f, 80.f, 0.f), 0.5f, cameraAngleText, Rgba::WHITE, bitmapFont);
	g_theRenderer->DrawTextMeta2D(Vector3(50.f, 40.f, 0.f), 0.5f, meshText, Rgba::BLUE, bitmapFont);
	g_theRenderer->DrawTextMeta2D(Vector3(50.f, 300.f, 0.f), 0.5f, motionTimeText, Rgba::WHITE, bitmapFont);
	g_theConsole->Render();


	g_theGame->DrawCrosshair();





	//g_theRenderer->FramebufferBind(nullptr);
	//g_theRenderer->m_fboToDrawWith->SetUniform("gTime", &m_age);
	//g_theRenderer->RenderPostProcess(g_theApp->m_fbo);
	//g_theRenderer->FramebufferCopyToBack(g_theApp->m_fbo);
}

void TheGame::DebugText(std::string text)
{
	//g_theRenderer->DrawText2D(Vector2(20.f, 800.f), text, 15.f, Rgba::WHITE, m_font);
}

void TheGame::DrawCrosshair()
{
	Rgba color = Rgba::WHITE;
	Vector2 xhairBottom = Vector2((float)snapBackPos.x, (float)snapBackPos.y - XHAIR_LENGTH);
	Vector2 xhairTop = Vector2((float)snapBackPos.x, (float)snapBackPos.y + XHAIR_LENGTH);
	Vector2 xhairLeft = Vector2((float)snapBackPos.x - XHAIR_LENGTH, (float)snapBackPos.y);
	Vector2 xhairRight = Vector2((float)snapBackPos.x + XHAIR_LENGTH, (float)snapBackPos.y);

	g_theRenderer->SetInverseDestBlend();
	g_theRenderer->DrawLine(xhairBottom, xhairTop, color.m_red, color.m_green, color.m_blue, color.m_alpha, 2.f);
	g_theRenderer->DrawLine(xhairLeft, xhairRight, color.m_red, color.m_green, color.m_blue, color.m_alpha, 2.f);
	g_theRenderer->SetAlphaBlend();
}

void TheGame::ClearBuilderPointers(MeshBuilder* &meshBuilder, MeshRenderer* &modelRender, Mesh* &mesh)
{
	delete meshBuilder;
	meshBuilder = nullptr;

	delete modelRender;
	modelRender = nullptr;

	delete mesh;
	mesh = nullptr;
}

void TheGame::PopulateJointMeshRenderer(Skeleton* skeleton)
{
	if (m_jointMeshRenderer.size() > 0)
	{
		m_jointMeshRenderer.clear();
	}

	for (unsigned int jointIndex = 0; jointIndex < skeleton->m_jointNames.size(); ++jointIndex)
	{
		m_jointMeshRenderer.push_back(new MeshRenderer(m_sphereMesh, m_materialStone,
			Transform(skeleton->GetJointPosition(jointIndex), mat44_fl::identity,
				Vector3(0.1f, 0.1f, 0.1f))));
	}
}

void DrawDebugArrow(Command& args)
{
	
	if (args.m_argList.empty())
	{
		g_theRenderer->AddDebugArrow(Vector3(1.f, 1.f, 1.f), Vector3(10.f, 50.f, 10.f), Rgba::YELLOW, 2.f, RenderCommand::XRAY);
	}
}
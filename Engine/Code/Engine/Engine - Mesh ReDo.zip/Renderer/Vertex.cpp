#include "Engine/Renderer/Vertex.hpp"


//-------------------------------------------------------------------------------------------------
Vertex_PCUTB::Vertex_PCUTB(Vector3 const &position /*= Vector3::ZERO*/, Rgba const &color /*= Rgba::WHITE*/, Vector2 const &texCoords /*= Vector2::ZERO*/, Vector3 const &tangent /*= Vector3(1.f,0.f,0.f)*/, Vector3 const &biTangent /*= Vector3(0.f,1.f,0.f) */)
	: m_position(position)
	, m_color(color)
	, m_texCoord(texCoords)
	, m_tangent(tangent)
	, m_biTangent(biTangent)
{

}


//-------------------------------------------------------------------------------------------------
Vertex_PCU::Vertex_PCU(const Vector3& position /*= Vector3::ZERO*/, const Rgba& color /*= Rgba::WHITE */, const Vector2& texCoords)
	: m_position(position)
	, m_color(color)
	, m_texCoord(texCoords)
{
}


//-------------------------------------------------------------------------------------------------
Vertex_PC::Vertex_PC(const Vector3& position /*= Vector3::ZERO*/, const Rgba& color /*= Rgba::WHITE */)
	: m_position(position)
	, m_color(color)
{
}
#pragma once

#include "Engine/Math/Vector2.hpp"
#include "Engine/Math/Vector3.hpp"
#include "Engine/Math/Rgba.hpp"


//-------------------------------------------------------------------------------------------------
enum VertexType
{
	VertexType_PC,
	VertexType_PCU,
	VertexType_PCUTB,
};


//-------------------------------------------------------------------------------------------------
struct Vertex_PCUTB
{
public:
	Vector3 m_position;
	Rgba m_color;
	Vector2 m_texCoord;
	Vector3 m_tangent;
	Vector3 m_biTangent;

public:
	Vertex_PCUTB(Vector3 const &position = Vector3::ZERO, Rgba const &color = Rgba::WHITE, Vector2 const &texCoords = Vector2::ZERO, Vector3 const &tangent = Vector3(1.f, 0.f, 0.f), Vector3 const &biTangent = Vector3(0.f, 1.f, 0.f));
};


//-------------------------------------------------------------------------------------------------
struct Vertex_PCU
{
public:
	Vector3 m_position;
	Rgba m_color;
	Vector2 m_texCoord;

public:
	Vertex_PCU(const Vector3& position = Vector3::ZERO, const Rgba& color = Rgba::WHITE, const Vector2& texCoords = Vector2::ZERO);
};


//-------------------------------------------------------------------------------------------------
struct Vertex_PC
{
public:
	Vector3 m_position;
	Rgba m_color;

public:
	Vertex_PC(const Vector3& position = Vector3::ZERO, const Rgba& color = Rgba::WHITE);
};
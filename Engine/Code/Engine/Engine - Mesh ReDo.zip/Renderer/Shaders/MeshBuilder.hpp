#pragma once

#include "Engine/Math/Rgba.hpp"
#include "Engine/Math/Vector2.hpp"
#include "Engine/Math/Vector3.hpp"
#include <vector>

class Mesh;


//-----------------------------------------------------------------------------------------------
struct DrawInstruction
{
	uint32_t primitiveType;
	uint32_t startIndex;
	uint32_t count;
	bool usesIndexBuffer;
};


//-----------------------------------------------------------------------------------------------
struct BuilderVertexDefinition
{
	size_t vertexSize; // Size of vertex data type
};


//-----------------------------------------------------------------------------------------------
struct VertexMaster
{
	Vector3 m_position;

	Vector3 m_tangent;
	Vector3 m_bitangent;
	Vector3 m_normal;

	Rgba m_color;

	Vector2 m_uv0;
	Vector2 m_uv1;
};

//-----------------------------------------------------------------------------------------------
typedef void(*VertexCopyCallback)(void* destination, const VertexMaster& source);
class MeshBuilder
{
public:
	MeshBuilder(); // Initializes the stamp

	void Begin();
	void End();

	void SetColor(const Rgba& color);
	void SetTangent(const Vector3& tangent);
	void SetBitangent(const Vector3& bitangent);
	void SetNormal(const Vector3& normal);
	void SetUV(float u, float v);

	void AddVertex(const Vector3& position);

	void CopyToMesh(Mesh* mesh, VertexCopyCallback copyCallback);
	std::vector< DrawInstruction> GetDrawInstructions() const { return m_drawInstructions; };
	std::vector< VertexMaster> GetVertexData() const { return m_vertices; };

private:
	int m_startIndexBuilder;
	VertexMaster m_stamp;
	std::vector< VertexMaster > m_vertices;
	std::vector< DrawInstruction > m_drawInstructions;
};
#pragma once

#include <vector>
#include "Engine/Renderer/Vertex.hpp"
#include "Engine/Renderer/VertexDefinition.hpp"
#include "Engine/Renderer/Shaders/MeshBuilder.hpp"


//-------------------------------------------------------------------------------------------------
class BitmapFont;


//-------------------------------------------------------------------------------------------------
enum MeshShape
{
	MeshShape_QUAD,
	MeshShape_CUBE,
	MeshShape_SPHERE,
	MeshShape_AXIS,
	MeshShape_COUNT,
};




//-------------------------------------------------------------------------------------------------
class Mesh
{
private:
	std::vector<VertexDefinition> m_layout;
	std::vector<DrawInstruction> m_drawInstructions;
	unsigned int m_vboID;
	unsigned int m_iboID;
	unsigned int drawMode;
	int m_indexBufferVertCount;

	static std::vector<Mesh*> s_defaultMeshes;
	

private:
	Mesh(MeshShape const &shape);

public:
	Mesh(std::string const &textString, float scale = 12.f, BitmapFont const *font = nullptr);
	Mesh(MeshBuilder const *meshBuilder, VertexType const &vertexType);
	~Mesh();

	unsigned int GetVBOID() const { return m_vboID; }
	unsigned int GetIBOID() const { return m_iboID; }
	unsigned int GetDrawMode() const { return drawMode; }
	int GetIBOorVertCount() const;
	std::vector< VertexDefinition > GetLayout() const;
	std::vector< DrawInstruction > const & GetDrawInstructions() const;
	int GetVertexSize() const;
	void SetVertexLayout(VertexType vertexType);
	void UpdateText(std::string newText, float scale = 12.f, BitmapFont const *font = nullptr);
	void Update(MeshBuilder const *meshBuilder, VertexType const &vertexType);

	static Mesh const * GetMeshShape(MeshShape const &meshShape);

	static void InitializeDefaultMeshes();
	static void DestroyDefaultMeshes();

	BuilderVertexDefinition* m_vertexDefinition;
	std::vector< DrawInstruction > m_drawInstructions;
};
void MeshBuildFace(MeshBuilder *builder, Vector3 lower_left, Vector3 top_left, Vector3 bottom_right);
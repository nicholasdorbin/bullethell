#include "Engine/Renderer/Shaders/MeshBuilder.hpp"
#include "Engine/Renderer/Renderer.hpp"
#include "Engine/Renderer/Shaders/Mesh.hpp"


//-----------------------------------------------------------------------------------------------
MeshBuilder::MeshBuilder()
{

}


//-----------------------------------------------------------------------------------------------
void MeshBuilder::Begin()
{
	m_startIndexBuilder = m_vertices.size();
}


//-----------------------------------------------------------------------------------------------
void MeshBuilder::End()
{
	if (m_startIndexBuilder < m_vertices.size())
	{
		// Create the draw instruction
		DrawInstruction instruction;
		instruction.primitiveType = GL_TRIANGLES;
		instruction.startIndex = m_startIndexBuilder;
		instruction.count = m_vertices.size() - m_startIndexBuilder;
		instruction.usesIndexBuffer = false;

		m_drawInstructions.push_back(instruction);
		// prevents double ends - though 
		// funny enough it 
		m_startIndexBuilder = m_vertices.size();
	}
}


//-----------------------------------------------------------------------------------------------
void MeshBuilder::SetColor(const Rgba& color)
{
	m_stamp.m_color = color;
}


//-----------------------------------------------------------------------------------------------
void MeshBuilder::SetTangent(const Vector3& tangent)
{
	m_stamp.m_tangent = tangent;
}


//-----------------------------------------------------------------------------------------------
void MeshBuilder::SetBitangent(const Vector3& bitangent)
{
	m_stamp.m_bitangent = bitangent;
}


//-----------------------------------------------------------------------------------------------
void MeshBuilder::SetNormal(const Vector3& normal)
{
	m_stamp.m_normal = normal;
}


//-----------------------------------------------------------------------------------------------
void MeshBuilder::SetUV(float u, float v)
{
	m_stamp.m_uv0 = Vector2(u, v);
}


//-----------------------------------------------------------------------------------------------
void MeshBuilder::AddVertex(const Vector3& position)
{
	m_stamp.m_position = position;
	m_vertices.push_back(m_stamp);
}


//-----------------------------------------------------------------------------------------------
void MeshBuilder::CopyToMesh(Mesh* mesh, VertexCopyCallback copyCallback)
{
	mesh->m_drawInstructions.clear();

	// First, we need to allocate a buffer to copy 
	// our vertices into, that matches what the mesh
	// wants.  
	size_t vertexCount = m_vertices.size();
	if (vertexCount == 0) {
		// nothing in this mesh.
		return;
	}

	size_t vertexSize = mesh->m_vertexDefinition->vertexSize;
	size_t vertexBufferSize = vertexCount * vertexSize;

	unsigned char* vertexBuffer = new unsigned char[vertexBufferSize];

	unsigned char* destination = vertexBuffer;
	for (size_t vertexIndex = 0; vertexIndex < vertexCount; ++vertexIndex)
	{
		copyCallback(destination, m_vertices[vertexIndex]);
		destination += vertexSize;
	}

	//mesh->vbo.write( vertex_buffer, vertex_buffer_size );
	// Adds buffer of vertex data to mesh

	// add all is psuedo - didn't want to write the loop
	//mesh->draw_instructions.add_all( draw_instructions );
	// Adds draw instructions for vertex data to mesh

	delete vertexBuffer;
	vertexBuffer = nullptr;
	delete destination;
	destination = nullptr;
}
//-----------------------------------------------------------------------------------------------
// Time.hpp
//	A simple high-precision time utility function for Windows
//	based on code by Squirrel Eiserloh
#pragma once
#include <time.h>

//-----------------------------------------------------------------------------------------------
double GetCurrentTimeSeconds();


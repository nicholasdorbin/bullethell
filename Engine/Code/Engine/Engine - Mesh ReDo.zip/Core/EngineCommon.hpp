#pragma once
class Camera3D;


extern  Camera3D g_camera;
extern float g_engineDeltaSeconds;
extern int g_effectState;
extern bool g_debugDrawing;
extern int g_lightState;

//-------------------------------------------------------------------------------------------------
// Engine Enumerators
//-------------------------------------------------------------------------------------------------
enum Blending
{
	Blending_NORMAL,
	Blending_SUBTRACTIVE,
	Blending_ADDITIVE,
	Blending_INVERTED,
};


//-------------------------------------------------------------------------------------------------
enum DrawMode
{
	DrawMode_FULL,
	DrawMode_LINE,
	DrawMode_POINT,
};

void InitializeEngineCommon();
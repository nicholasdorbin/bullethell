#include "Engine/Core/Camera3D.hpp"
#include "Engine/MathUtils.hpp"
#include "Engine/Math/Matrix44.hpp"


Camera3D::Camera3D()
	 :m_projection(mat44_fl::identity)
{
	m_position.SetXYZ(0.f, 0.f, 0.f);
	m_orientation = EulerAngles::ZERO;
	float aspect = 16.f / 9.f;
	MatrixMakePerspective(&m_projection, 70.f, aspect, 0.1f, 100.f);
	//MatrixMakeProjPerspective(&m_projection, aspect, DegToRad(60.f), 0.01f, 1000.f);
	//m_projection.MakePerspective(60.f, aspect, 0.01f, 1000.f);
}

Vector3 Camera3D::GetForwardXYZ()
{
	//Yaw = theta
	//phi = pitch nose down
	//(cos theta)*(cos phi),(sin theta)*(cos phi),(-sin phi)

	float cosYaw = CosDegrees(m_orientation.m_yawDegreesAboutZ);
	float sinYaw = SinDegrees(m_orientation.m_yawDegreesAboutZ);
	float cosPitch = CosDegrees(m_orientation.m_pitchDegreesAboutX);
	float sinPitch = SinDegrees(m_orientation.m_pitchDegreesAboutX);
	//return Vector3((cosYaw*cosPitch), (sinYaw * cosPitch), -sinPitch);//Simple Miner
	return Vector3((sinYaw * cosPitch), (cosYaw*cosPitch), sinPitch);

}

Vector3 Camera3D::GetForwardXY()
{
	float cosYaw = CosDegrees(m_orientation.m_yawDegreesAboutZ);
	float sinYaw = SinDegrees(m_orientation.m_yawDegreesAboutZ);
	return Vector3(sinYaw, cosYaw, 0.f);
}

Vector3 Camera3D::GetLeftXY()
{
	Vector3 forwardXY = GetForwardXY();
	return Vector3(-forwardXY.y, forwardXY.x, 0.f);
}

void Camera3D::FixAndClampAngles()
{

	m_orientation.m_pitchDegreesAboutX = ClampFloat(m_orientation.m_pitchDegreesAboutX, -90.f, 90.f);
	m_orientation.m_rollDegreesAboutY = ClampFloatCircular(m_orientation.m_rollDegreesAboutY, 0.f, 360.f);
	m_orientation.m_yawDegreesAboutZ = ClampFloatCircular(m_orientation.m_yawDegreesAboutZ, 0.f, 360.f);

}

//-------------------------------------------------------------------------------------------------
mat44_fl Camera3D::GetViewMatrix() const
{

	/*
	MatrixMakeRotationEuler(&view, g_camera.m_orientation.m_yawDegreesAboutZ, g_camera.m_orientation.m_pitchDegreesAboutX,
		g_camera.m_orientation.m_rollDegreesAboutY, g_camera.m_position);
	MatrixForsethCOBNick(&view);

	MatrixInvertOrthonormal(&view);
	*/
	mat44_fl view(mat44_fl::identity);
	//view.MakeBasis( Vector3( 1.f, 0.f, 0.f ), Vector3( 0.f, 1.f, 0.f ), Vector3( 0.f, 0.f, -1.f ) );
	
	//view.MakeRotationEuler(m_orientation, m_position);
	view.MakeRotationEuler(m_orientation, m_position);
	view.MatrixForsethCOBNick();
	//MatrixMakeRotationEuler(&view, m_orientation, m_position);
	//MatrixInvertOrthogonal(&view);
	view.InvertOrthonormal();
	return view;
}
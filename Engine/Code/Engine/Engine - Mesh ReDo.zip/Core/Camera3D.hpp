#pragma once
#include "Engine/Math/Vector3.hpp"
#include "Engine/Math/EulerAngles.hpp"
#include "Engine/Math/Matrix44.hpp"

class Camera3D
{
private:
	mat44_fl m_projection;
public:
	Camera3D();
	Vector3 GetForwardXYZ();
	Vector3 GetForwardXY();
	Vector3 GetLeftXY();
	void FixAndClampAngles();

	mat44_fl GetViewMatrix() const;
	Vector3 m_position;
	EulerAngles m_orientation;
	mat44_fl GetProjectionMatrix() const { return m_projection; }
};
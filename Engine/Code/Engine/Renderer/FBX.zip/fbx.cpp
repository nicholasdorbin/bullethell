#include "Engine/Tools/fbx.hpp"
#include "Engine/Core/ErrorWarningAssert.hpp"
#include "Engine/Core/Console.hpp"
#include "Engine/Renderer/Shaders/MeshBuilder.hpp"
#include "Engine/Math/Matrix44Stack.hpp"
#include "Engine/Renderer/Skeleton.hpp"

#define UNREFERENCED(x) x

#if defined(TOOLS_BUILD)
#include <fbxsdk.h>
#pragma comment(lib, "libfbxsdk-md.lib")
	//For TOOLS only
static Vector3 ToEngineVec3(FbxVector4 const &fbx_vec4)
{
	return Vector3((float)fbx_vec4.mData[0],
		(float)fbx_vec4.mData[1],
		(float)fbx_vec4.mData[2]);
}
//-----------------------------------------------------------------------------------------------
static Vector4 ToEngineVec4(FbxDouble4 const &v)
{
	return Vector4((float)v.mData[0],
		(float)v.mData[1],
		(float)v.mData[2],
		(float)v.mData[3]);
}


//-----------------------------------------------------------------------------------------------
static mat44_fl ToEngineMatrix(FbxMatrix const &fbx_mat)
{
	mat44_fl mat;
	MatrixSetRows(&mat,
		ToEngineVec4(fbx_mat.mData[0]),
		ToEngineVec4(fbx_mat.mData[1]),
		ToEngineVec4(fbx_mat.mData[2]),
		ToEngineVec4(fbx_mat.mData[3]));

	return mat;
}
static char const* GetAttributeType(FbxNodeAttribute::EType type)
{
	switch (type) {
	case FbxNodeAttribute::eUnknown: return "unidentified";
	case FbxNodeAttribute::eNull: return "null";
	case FbxNodeAttribute::eMarker: return "marker";
	case FbxNodeAttribute::eSkeleton: return "skeleton";
	case FbxNodeAttribute::eMesh: return "mesh";
	case FbxNodeAttribute::eNurbs: return "nurbs";
	case FbxNodeAttribute::ePatch: return "patch";
	case FbxNodeAttribute::eCamera: return "camera";
	case FbxNodeAttribute::eCameraStereo: return "stereo";
	case FbxNodeAttribute::eCameraSwitcher: return "camera switcher";
	case FbxNodeAttribute::eLight: return "light";
	case FbxNodeAttribute::eOpticalReference: return "optical reference";
	case FbxNodeAttribute::eOpticalMarker: return "marker";
	case FbxNodeAttribute::eNurbsCurve: return "nurbs curve";
	case FbxNodeAttribute::eTrimNurbsSurface: return "trim nurbs surface";
	case FbxNodeAttribute::eBoundary: return "boundary";
	case FbxNodeAttribute::eNurbsSurface: return "nurbs surface";
	case FbxNodeAttribute::eShape: return "shape";
	case FbxNodeAttribute::eLODGroup: return "lodgroup";
	case FbxNodeAttribute::eSubDiv: return "subdiv";
	default: return "unknown";
	}
}

static void PrintAttribute(FbxNodeAttribute *attribute, int depth)
{
	if (nullptr == attribute)
	{
		return;
	}

	FbxNodeAttribute::EType type =
		attribute->GetAttributeType();

	char const *type_name = GetAttributeType(type);
	char const *attrib_name = attribute->GetName();

	DebuggerPrintf("%*s- type='%s', name='%s'", depth, " ", type_name, attrib_name);

}

static void PrintNode(FbxNode *node, int depth)
{
	DebuggerPrintf("%*sNode [%s] \n", depth, " ", node->GetName());

	for (int i = 0; i < node->GetNodeAttributeCount(); ++i)
	{
		PrintAttribute(node->GetNodeAttributeByIndex(i), depth);
	}

	for (int32_t i = 0; i < node->GetChildCount(); ++i)
	{
		PrintNode(node->GetChild(i), depth + 1);
	}
}

void FbxListScene(std::string filename)
{
	FbxManager *fbx_manager = FbxManager::Create();
	if (nullptr == fbx_manager)
	{
		DebuggerPrintf("Could not create fbx manager.");
		return;
	}

	FbxIOSettings *io_settings =
		FbxIOSettings::Create(fbx_manager, IOSROOT);
	fbx_manager->SetIOSettings(io_settings);

	//Create importer
	FbxImporter *importer =
		FbxImporter::Create(fbx_manager, "");

	bool result = importer->Initialize(filename.c_str(), -1, fbx_manager->GetIOSettings());

	if (result)
	{
		//we have imported the FBX
		FbxScene *scene = FbxScene::Create(fbx_manager, "");

		bool import_successful = importer->Import(scene);
		if (import_successful)
		{
			FbxNode *root = scene->GetRootNode();
			PrintNode(root, 0);
		}

		FBX_SAFE_DESTROY(scene);
	}
	else
	{
		DebuggerPrintf("Could not import scene: %s", filename);
	}

	FBX_SAFE_DESTROY(importer);
	FBX_SAFE_DESTROY(io_settings);
	FBX_SAFE_DESTROY(fbx_manager);



	g_theConsole->ConsolePrint("Fbx List called");
}
/*
COMMAND(fbx_list)
{
	std::string filename = args.get_next_string();
	FbxListScene(filename);
}
*/

void FbxList(Command& args)
{

	std::string filename = args.m_argList[1];
	FbxListScene(filename);
}

#define ASSERT_RETURN(e) if(!e) {DebugBreak();return;}

static Vector3 ToVec3(FbxVector4 const &fbx_vec4)
{
	return Vector3((float)fbx_vec4.mData[0],
		(float)fbx_vec4.mData[1],
		(float)fbx_vec4.mData[2]);
}




static bool GetPosition(Vector3 *outPosition,
	mat44_fl const &transform,
	FbxMesh *mesh,
	int polyIndex,
	int vertIndex)
{
	FbxVector4 fbx_pos;
	int control_index = mesh->GetPolygonVertex(polyIndex, vertIndex);

	fbx_pos = mesh->GetControlPointAt(control_index);
	//#TODO Fix for our Row matrixes, not collumns
	//*outPosition = transform * Vector4(ToVec3(fbx_pos),1.f).GetXYZ();
	*outPosition = ( Vector4(ToEngineVec3(fbx_pos), 1.0f) * transform).GetXYZ();
	return true;
}

template <typename ElemType, typename VarType>
static bool GetObjectFromElement(FbxMesh *mesh,
	int poly_idx,
	int vert_idx,
	ElemType *elem,
	VarType *out_var)
{
	if (nullptr == elem) {
		return false;
	}

	switch (elem->GetMappingMode()) {
	case FbxGeometryElement::eByControlPoint:
	{
		int control_idx = mesh->GetPolygonVertex(poly_idx, vert_idx);
		switch (elem->GetReferenceMode()) {
		case FbxGeometryElement::eDirect:
			if (control_idx < elem->GetDirectArray().GetCount()) {
				*out_var = elem->GetDirectArray().GetAt(control_idx);
				return true;
			}
			break;

		case FbxGeometryElement::eIndexToDirect:
			if (control_idx < elem->GetIndexArray().GetCount()) {
				int index = elem->GetIndexArray().GetAt(control_idx);
				*out_var = elem->GetDirectArray().GetAt(index);
				return true;
			}
			break;

		default:
			break;
		}
	} break;

	case FbxGeometryElement::eByPolygonVertex:
	{
		int direct_vert_idx = (poly_idx * 3) + vert_idx;
		switch (elem->GetReferenceMode())
		{
		case FbxGeometryElement::eDirect:
			if (direct_vert_idx < elem->GetDirectArray().GetCount()) {
				*out_var = elem->GetDirectArray().GetAt(direct_vert_idx);
				return true;
			}
			break;

		case FbxGeometryElement::eIndexToDirect:
			if (direct_vert_idx < elem->GetIndexArray().GetCount()) {
				int index = elem->GetIndexArray().GetAt(direct_vert_idx);
				*out_var = elem->GetDirectArray().GetAt(index);
				return true;
			}
			break;

		default:
			break;
		}
	} break;

	default:
		//ASSERT_OR_DIE("Undefined mapping mode.");
		break;
	}

	return false;
}


static bool GetColor(Vector4 *out_color,
	mat44_fl const &transform,
	FbxMesh *mesh,
	int poly_idx,
	int vert_idx)
{
	transform;

	FbxColor color;
	FbxGeometryElementVertexColor *colors = mesh->GetElementVertexColor(0);
	if (GetObjectFromElement(mesh, poly_idx, vert_idx, colors, &color)) {
		Vector4 vec4color = Vector4((float)color.mRed, (float)color.mGreen, (float)color.mBlue, (float)color.mAlpha);
		*out_color = vec4color;
		return true;
	}

	return false;
}

static bool GetNormal(Vector3 *out_normal,
	mat44_fl const &transform,
	FbxMesh *mesh,
	int poly_idx,
	int vert_idx)
{
	FbxVector4 normal;
	FbxGeometryElementNormal *uvs = mesh->GetElementNormal(0);
	if (GetObjectFromElement(mesh, poly_idx, vert_idx, uvs, &normal)) {
		Vector3 n = ToVec3(normal);
		*out_normal = ( Vector4(n, 0.0f) * transform).GetXYZ();
		return true;
	}

	return false;
}

static bool GetUV(Vector2 *out_uv,
	FbxMesh *mesh,
	int poly_idx,
	int vert_idx,
	int uv_idx)
{
	FbxVector2 uv;
	FbxGeometryElementUV *uvs = mesh->GetElementUV(uv_idx);
	if (GetObjectFromElement(mesh, poly_idx, vert_idx, uvs, &uv))
	{
		*out_uv = Vector2((float)uv.mData[0], (float)uv.mData[1]);
		return true;
	}
	return false;
}


static void ImportVertex(MeshBuilder *mb,
	mat44_fl const &transform,
	FbxMesh *mesh,
	int polyIndex,
	int vertIndex)
{

	Vector3 normal;
	if (GetNormal(&normal, transform, mesh, polyIndex, vertIndex))
	{
		mb->SetNormal(normal);
		//#TODO: Remove once we have a vertex that supports only normals
		Vector3 bitangent = Vector3(0.f, 0.f, 1.f);
		if (normal == bitangent)
		{
			bitangent = Vector3(0.f, 1.f, 0.f);
		}
		Vector3 tangent = CrossProduct(bitangent, normal);
		bitangent = CrossProduct(normal, tangent);

		mb->SetTangent(tangent);
		mb->SetBitangent(bitangent);
	}

	Vector4 color;
	if (GetColor(&color, transform, mesh, polyIndex, vertIndex)) {
		unsigned char red = (unsigned char)RangeMap(color.x, 0.0f, 1.0f, 0.0f, 255.0f);
		unsigned char green = (unsigned char)RangeMap(color.y, 0.0f, 1.0f, 0.0f, 255.0f);
		unsigned char blue = (unsigned char)RangeMap(color.z, 0.0f, 1.0f, 0.0f, 255.0f);
		unsigned char alpha = (unsigned char)RangeMap(color.w, 0.0f, 1.0f, 0.0f, 255.0f);
		mb->SetColor(Rgba(red, green, blue, alpha));
	}


	Vector2 uv;

	if (GetUV(&uv, mesh, polyIndex, vertIndex, 0))
	{
		mb->SetUV0(uv);
	}

	Vector3 position;
	if (GetPosition(&position,transform, mesh, polyIndex, vertIndex))
	{
		mb->AddVertex(position);
	}
}

static void ImportMesh(SceneImport *import,
	FbxMesh *mesh,
	Matrix4x4Stack &mat_stack)
{
	MeshBuilder *mb = new MeshBuilder();

	ASSERT_RETURN(mesh->IsTriangleMesh());
	
	mat44_fl transform = mat_stack.GetTop();

	int poly_count = mesh->GetPolygonCount();
	for (int poly_idx = 0; poly_idx < poly_count; ++poly_idx) {
		int vert_count = mesh->GetPolygonSize(poly_idx);
		//ASSERT_OR_DIE(vert_count == 3);
		for (int vert_idx = 0; vert_idx < vert_count; ++vert_idx) {
			ImportVertex(mb, transform, mesh, poly_idx, vert_idx);
		}
	}

	mb->End();
	//Import the mesh

	import->meshes.push_back(mb);
}

static void ImportNodeAttribute(SceneImport *import,
	FbxNodeAttribute *attrib,
	Matrix4x4Stack &mat_stack)
{
	if (attrib == nullptr)
	{
		return;
	}

	switch (attrib->GetAttributeType())
	{
	case FbxNodeAttribute::eMesh:
	{
		ImportMesh(import, (FbxMesh*)attrib, mat_stack);
		break;
	}
	default:
		break;
		
	}

}

static mat44_fl GetNodeTransform(FbxNode *node)
{
	FbxMatrix fbx_local_matrix = node->EvaluateLocalTransform();
	return ToEngineMatrix(fbx_local_matrix);
	//#TODO Write this function
	return mat44_fl();

}

static void ImportSceneNode(SceneImport *import,
	FbxNode *node,
	Matrix4x4Stack &mat_stack)
{
	if (nullptr == node)
	{
		return;
	}

	mat44_fl node_local_transform = GetNodeTransform(node);
	mat_stack.Push(node_local_transform);

	//Load Mesh
	int attrib_count = node->GetNodeAttributeCount();
	for (int attrib_index = 0; attrib_index < attrib_count; ++attrib_index)
	{
		ImportNodeAttribute(import, node->GetNodeAttributeByIndex(attrib_index), mat_stack);
	}

	//Import Children
	int childCount = node->GetChildCount();
	for (int childIndex = 0; childIndex < childCount; ++childIndex)
	{
		ImportSceneNode(import, node->GetChild(childIndex), mat_stack);
	}

	mat_stack.Pop();
}

static void TriangulateScene(FbxScene *scene)
{
	FbxGeometryConverter converter(scene->GetFbxManager());
	converter.Triangulate(scene, true/*replaces nodes with a traigulated mesh*/);
}

static Skeleton* ImportJoint(SceneImport *import,
	Matrix4x4Stack &mat_stack,
	Skeleton *cur_skeleton,
	int parent_joint_idx,
	FbxSkeleton *fbx_skeleton)
{
	Skeleton *ret_skeleton = nullptr;

	if (fbx_skeleton->IsSkeletonRoot()) {
		// NEW SKELETON!
		ret_skeleton = new Skeleton();
		import->skeletons.push_back(ret_skeleton);
	}
	else {
		ret_skeleton = cur_skeleton;
		ASSERT_OR_DIE(ret_skeleton != nullptr, nullptr);
	}

	// Same as we did for meshes.  Usually this is the identity, but some 
	// modeling programs use it.
	mat44_fl geo_transform = GetNodeTransform(fbx_skeleton->GetNode());
	mat_stack.Push(geo_transform);

	mat44_fl model_matrix = mat_stack.GetTop();
	ret_skeleton->AddJoint(fbx_skeleton->GetNode()->GetName(),
		parent_joint_idx,
		model_matrix);

	mat_stack.Pop();
	return ret_skeleton;
}

static void ImportSkeletons(SceneImport *import,
	FbxNode *node,
	Matrix4x4Stack &matrix_stack,
	Skeleton *cur_skeleton, 	// Skeleton I'm adding to
	int parent_joint_idx)		// Last Joint Added
{
	// Most of this will look familiar
	if (nullptr == node) {
		return;
	}

	mat44_fl mat = GetNodeTransform(node);
	matrix_stack.Push(mat);

	int attrib_count = node->GetNodeAttributeCount();
	for (int attrib_idx = 0; attrib_idx < attrib_count; ++attrib_idx) {
		FbxNodeAttribute *attrib = node->GetNodeAttributeByIndex(attrib_idx);
		if ((attrib != nullptr)
			&& (attrib->GetAttributeType() == FbxNodeAttribute::eSkeleton)) {

			Skeleton *new_skeleton = ImportJoint(import,
				matrix_stack,
				cur_skeleton,
				parent_joint_idx,
				(FbxSkeleton*)attrib);

			// new_skeleton will either be the same skeleton
			// passed in, no skeleton, or a new skeleton
			// in the case of a new skeleton or same skeleton
			// it will become the skeleton we pass to all our
			// children.
			if (nullptr != new_skeleton) {
				cur_skeleton = new_skeleton;
				parent_joint_idx = cur_skeleton->GetLastAddedIndex();
			}
		}
	}

	// Go down the tree!
	int child_count = node->GetChildCount();
	for (int child_idx = 0; child_idx < child_count; ++child_idx) {
		ImportSkeletons(import,
			node->GetChild(child_idx),
			matrix_stack,
			cur_skeleton,
			parent_joint_idx);
	}

	matrix_stack.Pop();
}

static void ImportScene(SceneImport *import, FbxScene *scene, Matrix4x4Stack &mat_stack)
{
	TriangulateScene(scene);

	FbxNode *node = scene->GetRootNode();
	ImportSkeletons(import, node, mat_stack, nullptr, -1);
	ImportSceneNode(import, node, mat_stack);
}


static mat44_fl GetSceneBasis(FbxScene* scene)
{
	fbxsdk::FbxAxisSystem axis_system = scene->GetGlobalSettings().GetAxisSystem();
	FbxAMatrix mat;
	axis_system.GetMatrix(mat);

	return ToEngineMatrix(mat);
}

SceneImport* FbxLoadSceneFromFile(std::string filename,
	mat44_fl engine_basis,
	bool is_engine_basis_right_handed,
	mat44_fl transform)
{

	/*
	FbxScene *scene = //Get the scene

	SceneImport *import = new SceneImport();
	Matrix4x4Stack mat_stack;
	ImportScene(import,scene, matrix_stack);

	//Do normal kind of cleanup

	return import;
	*/
	FbxManager *fbx_manager = FbxManager::Create();
	if (nullptr == fbx_manager)
	{
		DebuggerPrintf("Could not create fbx manager.");
		return nullptr;
	}

	FbxIOSettings *io_settings =
		FbxIOSettings::Create(fbx_manager, IOSROOT);
	fbx_manager->SetIOSettings(io_settings);

	//Create importer
	FbxImporter *importer =
		FbxImporter::Create(fbx_manager, "");

	bool result = importer->Initialize(filename.c_str(), -1, fbx_manager->GetIOSettings());

	if (result)
	{
		//we have imported the FBX
		FbxScene *scene = FbxScene::Create(fbx_manager, "");

		bool import_successful = importer->Import(scene);
		if (import_successful)
		{
			FbxNode *root = scene->GetRootNode();
			SceneImport *import = new SceneImport();
			Matrix4x4Stack mat_stack;

			mat_stack.Push(transform);
			mat_stack.Push(engine_basis);

			//Set up initial transforms
			mat44_fl scene_basis = GetSceneBasis(scene);
			MatrixTranspose(&scene_basis);

			if (!is_engine_basis_right_handed)
			{
				Vector3 forward = MatrixGetForward(&scene_basis);
				MatrixSetForward(&scene_basis, -forward);

			}
			mat_stack.Push(scene_basis);

			ImportScene(import, scene, mat_stack);

			return import;
		}

		FBX_SAFE_DESTROY(scene);
	}
	else
	{
		DebuggerPrintf("Could not import scene: %s", filename);
	}

	FBX_SAFE_DESTROY(importer);
	FBX_SAFE_DESTROY(io_settings);
	FBX_SAFE_DESTROY(fbx_manager);



	g_theConsole->ConsolePrint("Fbx Load called");
}
#else //!defined (TOOLS_BUILD)
void FbxListScene(std::string filename) {}

SceneImport* FbxLoadSceneFromFile(std::string filename) { return nullptr; }

#endif
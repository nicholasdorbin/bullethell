#pragma once

#include <string>
#include <vector>

#include "Engine/Math/Matrix44.hpp"
#include "Engine/Math/Vector3.hpp"


//-----------------------------------------------------------------------------------------------
class Skeleton
{
public:
	void AddJoint(const std::string& jointName, int jointParentIndex, const mat44_fl& initialBoneSpace);

public:
	std::vector< std::string > m_jointNames;
	std::vector< int > m_jointParentIndicies;
	std::vector< mat44_fl > m_modelToBoneSpace;	// For initial model space layout
	std::vector< mat44_fl > m_boneToModelSpace;	// For current bone's model space

	std::string const& GetName() const;
	Vector3 GetJointPosition(int idx) const;
	bool GetBonePositions(int idx, Vector3 *out_p0, Vector3 *out_p1) const;

	int GetJointCount() const;
	int GetLastAddedIndex() const
	{
		return m_jointNames.size() - 1;
	}
};
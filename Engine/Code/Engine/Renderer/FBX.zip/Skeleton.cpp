#include "Engine/Renderer/Skeleton.hpp"


//-----------------------------------------------------------------------------------------------
void Skeleton::AddJoint(const std::string& jointName, int parentJointIndex, const mat44_fl& initialBoneSpace)
{
	m_jointNames.push_back(jointName);
	m_jointParentIndicies.push_back(parentJointIndex);
	m_boneToModelSpace.push_back(initialBoneSpace);

	mat44_fl modelToBoneMatrix = initialBoneSpace;
	MatrixInvert(&modelToBoneMatrix);
	m_modelToBoneSpace.push_back(modelToBoneMatrix);
}
#pragma once

#include <vector>
#include <string>

#include "Engine/Renderer/Shaders/Uniform.hpp"
#include "Engine/Renderer/Shaders/Attribute.hpp"
#include "Engine/Renderer/Shaders/ShaderProgram.hpp"


//-----------------------------------------------------------------------------------------------
class Material
{
public:
	Material(std::string vertexShaderFile, std::string fragmentShaderFile);
	Uniform* GetNewUniformByType(GLenum type);
	Attribute* GetNewAttributeByType(GLenum type);
	void SetUniform(std::string name, void* value);
	void SetAttribute(std::string name);

	GLuint CreateSampler(GLenum min_filter, GLenum mag_filter, GLenum u_wrap, GLenum v_wrap);
	void BindTextures();
public:
	ShaderProgram* m_shaderProgram;
	std::vector< Uniform* > m_uniforms;
	std::vector< Attribute* > m_attributes;
	std::vector<int> m_texIDs;
	GLuint m_samplerID;
};
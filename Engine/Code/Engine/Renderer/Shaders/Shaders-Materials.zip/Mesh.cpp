#include "Engine/MathUtils.hpp"
#include "Engine/Renderer/Shaders/Mesh.hpp"
#include "Engine/Renderer/Shaders/Material.hpp""


//-----------------------------------------------------------------------------------------------
Mesh::Mesh()
{
}


//-----------------------------------------------------------------------------------------------
void Mesh::MakeCubeMesh()
{
	// Add all vertexes to the mesh for VAO
	// Front face
	m_verts.push_back(Vertex3D_PCT(Vector3(-.5f, -.5f, .5f), Rgba::WHITE, Vector2(0.f, 0.f))); //tl
	m_verts.push_back(Vertex3D_PCT(Vector3(-.5f, -.5f, -.5f), Rgba::WHITE, Vector2(0.f, 1.f))); //bl
	m_verts.push_back(Vertex3D_PCT(Vector3(.5f, -.5f, -.5f), Rgba::WHITE, Vector2(1.f, 1.f))); //br
	m_verts.push_back(Vertex3D_PCT(Vector3(.5f, -.5f, .5f), Rgba::WHITE, Vector2(1.f, 0.f))); //tr

																							//  Back face
	m_verts.push_back(Vertex3D_PCT(Vector3(.5f, .5f, .5f), Rgba::WHITE, Vector2(0.f, 0.f))); //tl
	m_verts.push_back(Vertex3D_PCT(Vector3(.5f, .5f, -.5f), Rgba::WHITE, Vector2(0.f, 1.f))); //bl
	m_verts.push_back(Vertex3D_PCT(Vector3(-.5f, .5f, -.5f), Rgba::WHITE, Vector2(1.f, 1.f))); //br
	m_verts.push_back(Vertex3D_PCT(Vector3(-.5f, .5f, .5f), Rgba::WHITE, Vector2(1.f, 0.f))); //tr

																							// Top face
	m_verts.push_back(Vertex3D_PCT(Vector3(-.5f, .5f, .5f), Rgba::WHITE, Vector2(0.f, 0.f))); //tl
	m_verts.push_back(Vertex3D_PCT(Vector3(-.5f, -.5f, .5f), Rgba::WHITE, Vector2(0.f, 1.f))); //bl
	m_verts.push_back(Vertex3D_PCT(Vector3(.5f, -.5f, .5f), Rgba::WHITE, Vector2(1.f, 1.f))); //br
	m_verts.push_back(Vertex3D_PCT(Vector3(.5f, .5f, .5f), Rgba::WHITE, Vector2(1.f, 0.f))); //tr

																						   // Bottom Face
	m_verts.push_back(Vertex3D_PCT(Vector3(.5f, .5f, -.5f), Rgba::WHITE, Vector2(0.f, 0.f))); //tr
	m_verts.push_back(Vertex3D_PCT(Vector3(.5f, -.5f, -.5f), Rgba::WHITE, Vector2(0.f, 1.f))); //br
	m_verts.push_back(Vertex3D_PCT(Vector3(-.5f, -.5f, -.5f), Rgba::WHITE, Vector2(1.f, 1.f))); //bl
	m_verts.push_back(Vertex3D_PCT(Vector3(-.5f, .5f, -.5f), Rgba::WHITE, Vector2(1.f, 0.f))); //tl

																							 // Right face
	m_verts.push_back(Vertex3D_PCT(Vector3(.5f, .5f, .5f), Rgba::WHITE, Vector2(1.f, 0.f))); //tr
	m_verts.push_back(Vertex3D_PCT(Vector3(.5f, -.5f, .5f), Rgba::WHITE, Vector2(0.f, 0.f))); //br
	m_verts.push_back(Vertex3D_PCT(Vector3(.5f, -.5f, -.5f), Rgba::WHITE, Vector2(0.f, 1.f))); //bl
	m_verts.push_back(Vertex3D_PCT(Vector3(.5f, .5f, -.5f), Rgba::WHITE, Vector2(1.f, 1.f))); //tl

																							// Left face
	m_verts.push_back(Vertex3D_PCT(Vector3(-.5f, .5f, -.5f), Rgba::WHITE, Vector2(0.f, 1.f))); //tl
	m_verts.push_back(Vertex3D_PCT(Vector3(-.5f, -.5f, -.5f), Rgba::WHITE, Vector2(1.f, 1.f))); //bl
	m_verts.push_back(Vertex3D_PCT(Vector3(-.5f, -.5f, .5f), Rgba::WHITE, Vector2(1.f, 0.f))); //br
	m_verts.push_back(Vertex3D_PCT(Vector3(-.5f, .5f, .5f), Rgba::WHITE, Vector2(0.f, 0.f))); //tr

	// Add all indices to the mesh for IBO
	m_indices = {
		0, 1, 2,
		0, 2, 3,

		4, 5, 6,
		4, 6, 7,

		8, 9, 10,
		8, 10, 11,

		12, 13, 14,
		12, 14, 15,

		16, 17, 18,
		16, 18, 19,

		20, 21, 22,
		20, 22, 23
	};

	m_VBO = BufferCreate(&m_verts[0], m_verts.size(), sizeof(m_verts[0]), GL_STATIC_DRAW);

	m_IBO = BufferCreate(&m_indices[0], m_indices.size(), sizeof(m_indices[0]), GL_STATIC_DRAW);
}


//-----------------------------------------------------------------------------------------------
void Mesh::MakeSphereMesh()
{
	// Add all vertexes to the mesh for VAO, add all indices to the mesh for IBO
	float radius = 1.0f;
	int numRings = 100;
	int numSectors = 100;
	int currentRow = 0;
	int nextRow = 0;
	int nextSector;

	float const R = 1.0f / (float)(numRings - 1);
	float const S = 1.0f / (float)(numSectors - 1);

	for (int r = 0; r < numRings; ++r)
	{
		for (int s = 0; s < numSectors; ++s)
		{
			float const z = sin(-pi / 2 + pi * r * R);
			float const y = cos(2 * pi * s * S) * sin(pi * r * R);
			float const x = sin(2 * pi * s * S) * sin(pi * r * R);

			m_verts.push_back(Vertex3D_PCT(Vector3(x * radius + 5.f, y * radius, -z * radius), Rgba::WHITE, Vector2 (1 - s * S, r * R)));

			currentRow = r * numSectors;
			nextRow = (r + 1) * numSectors;
			nextSector = (s + 1) % numSectors;

			if (r < numRings - 1)
			{
				m_indices.push_back((uint16_t)(nextRow + nextSector));
				m_indices.push_back((uint16_t)(nextRow + s));
				m_indices.push_back((uint16_t)(currentRow + s));

				m_indices.push_back((uint16_t)(currentRow + nextSector));
				m_indices.push_back((uint16_t)(nextRow + nextSector));
				m_indices.push_back((uint16_t)(currentRow + s));
			}
		}
	}
	m_VBO = BufferCreate(&m_verts[0], m_verts.size(), sizeof(m_verts[0]), GL_STATIC_DRAW);

	m_IBO = BufferCreate(&m_indices[0], m_indices.size(), sizeof(m_indices[0]), GL_STATIC_DRAW);
}

GLuint Mesh::BufferCreate(void *data, size_t count, size_t elem_size, GLenum usage)
{
	GLuint  buffer;
	glGenBuffers(1, &buffer);

	glBindBuffer(GL_ARRAY_BUFFER, buffer);
	glBufferData(GL_ARRAY_BUFFER, count * elem_size, data, usage);
	glBindBuffer(GL_ARRAY_BUFFER, NULL);

	return buffer;
}

void Mesh::BindWithMaterial(Material* mat)
{
	glGenVertexArrays(1, &m_VAO);
	if (m_VAO != NULL)
	{
		glBindVertexArray(m_VAO);
		glBindBuffer(GL_ARRAY_BUFFER, m_VBO);


		mat->SetAttribute("inPosition");
		mat->SetAttribute("inColor");
		mat->SetAttribute("inUV0");

		glBindBuffer(GL_ARRAY_BUFFER, NULL);

		if (NULL != m_IBO) {
			glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, m_IBO);
		}

		glBindVertexArray(NULL);
	}
}

void Mesh::DrawWithMaterial(Material* mat)
{
	glBindVertexArray(m_VAO);
	glUseProgram((GLuint)mat->m_shaderProgram);
	glDrawElements(GL_TRIANGLES, m_indices.size(), GL_UNSIGNED_SHORT, (GLvoid*)0);
}

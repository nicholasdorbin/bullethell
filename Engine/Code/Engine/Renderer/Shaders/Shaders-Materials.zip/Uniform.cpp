#include "Engine/Renderer/Shaders/Uniform.hpp"


//-----------------------------------------------------------------------------------------------
Uniform::Uniform()
	: m_location(-1)
	, m_name("")
	, m_type(GL_INT)
{
}


//-----------------------------------------------------------------------------------------------
bool Uniform::BindUniform()
{
	return true;
}


//-----------------------------------------------------------------------------------------------
UniformInt::UniformInt()
	: m_value(NULL)
{
}


//-----------------------------------------------------------------------------------------------
bool UniformInt::BindUniform()
{
	if (m_location >= 0)
	{
		glUniform1iv(m_location, 1, (GLint*)&m_value);
		return true;
	}

	return false;
}


//-----------------------------------------------------------------------------------------------
UniformFloat::UniformFloat()
	: m_value(0.0f)
{
}


//-----------------------------------------------------------------------------------------------
bool UniformFloat::BindUniform()
{
	if (m_location >= 0)
	{
		glUniform1fv(m_location, 1, (GLfloat*)&m_value);
		return true;
	}

	return false;
}


//-----------------------------------------------------------------------------------------------
UniformVec3::UniformVec3()
	: m_value(Vector3::ZERO)
{
}


//-----------------------------------------------------------------------------------------------
bool UniformVec3::BindUniform()
{
	if (m_location >= 0)
	{
		glUniform3fv(m_location, 1, (GLfloat*)&m_value);
		return true;
	}

	return false;
}


//-----------------------------------------------------------------------------------------------
UniformVec4::UniformVec4()
	: m_value(Vector4::ZERO)
{
}


//-----------------------------------------------------------------------------------------------
bool UniformVec4::BindUniform()
{
	if (m_location >= 0)
	{
		glUniform4fv(m_location, 1, (GLfloat*)&m_value);
		return true;
	}

	return false;
}


//-----------------------------------------------------------------------------------------------
UniformMat4::UniformMat4()
	: m_value(mat44_fl::identity)
{
}


//-----------------------------------------------------------------------------------------------
bool UniformMat4::BindUniform()
{
	if (m_location >= 0)
	{
		glUniformMatrix4fv(m_location, 1, GL_FALSE, (GLfloat*)&m_value);
		return true;
	}

	return false;
}
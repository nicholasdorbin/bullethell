#include "Engine/Renderer/Shaders/Material.hpp"
#include "Engine/Core/ErrorWarningAssert.hpp"

//-----------------------------------------------------------------------------------------------
Material::Material(std::string vertexShaderFile, std::string fragmentShaderFile)
	: m_shaderProgram(new ShaderProgram(vertexShaderFile, fragmentShaderFile))
{
	m_samplerID = CreateSampler(GL_NEAREST, GL_NEAREST, GL_REPEAT, GL_REPEAT);
	GLint numberOfActiveUniforms = 0;
	GLint numberOfActiveAttributes = 0;
	GLint uniformMaxLength = 0;
	GLuint programID = m_shaderProgram->m_programID;
	glUseProgram(programID);
	glGetProgramiv(programID, GL_ACTIVE_UNIFORMS, &numberOfActiveUniforms);
	glGetProgramiv(programID, GL_ACTIVE_UNIFORM_MAX_LENGTH, &uniformMaxLength);

	for (int i = 0; i < numberOfActiveUniforms; ++i)
	{
		GLsizei length;
		GLint size;
		GLenum type;
		std::vector< GLchar > nameData(256);
		glGetActiveUniform(programID, i, nameData.size(), &length, &size, &type, &nameData[0]);

		GLint location = -1;
		location = glGetUniformLocation(programID, &nameData[0]);

		Uniform* newUniform = GetNewUniformByType(type);
		newUniform->m_type = type;
		newUniform->m_name = std::string(nameData.begin(), nameData.begin() + length);
		newUniform->m_location = location;
		m_uniforms.push_back(newUniform);
	}

	glGetProgramiv(programID, GL_ACTIVE_ATTRIBUTES, &numberOfActiveAttributes);
	for (int i = 0; i < numberOfActiveAttributes; ++i)
	{
		GLsizei length;
		GLint size;
		GLenum type;
		std::vector< GLchar > nameData(256);
		glGetActiveAttrib(programID, i, nameData.size(), &length, &size, &type, &nameData[0]);

		GLint location = -1;
		location = glGetAttribLocation(programID, &nameData[0]);

		Attribute* newAttrib = GetNewAttributeByType(type);
		newAttrib->m_type = type;
		newAttrib->m_name = std::string(nameData.begin(), nameData.begin() + length);
		newAttrib->m_location = location;
		m_attributes.push_back(newAttrib);
	}
}


//-----------------------------------------------------------------------------------------------
Uniform* Material::GetNewUniformByType(GLenum type)
{
	switch (type)
	{
	case GL_INT:
		return new UniformInt();
		break;
	case GL_FLOAT:
		return new UniformFloat();
		break;
	case GL_FLOAT_VEC3:
		return new UniformVec3();
		break;
	case GL_FLOAT_VEC4:
		return new UniformVec4();
		break;
	case GL_FLOAT_MAT4:
		return new UniformMat4();
		break;
	case GL_SAMPLER_2D:
		return new UniformInt();
		break;
	default:
		return nullptr;
		break;
	}
}
Attribute* Material::GetNewAttributeByType(GLenum type)
{
	switch (type)
	{
	case GL_FLOAT_VEC2:
		return new AttributeVec2();
		break;
	case GL_FLOAT_VEC3:
		return new AttributeVec3();
		break;
	case GL_FLOAT_VEC4:
		return new AttributeVec4();
		break;
	default:
		return nullptr;
		break;
	}
}

void Material::SetUniform(std::string name, void* value)
{
	//TODO
	//Find name uniform in Vector
	bool isFound = false;
	for (auto nameIter = m_uniforms.begin(); nameIter != m_uniforms.end(); ++nameIter)
	{
		std::string uniformName = (*nameIter)->m_name;
		if (uniformName == name)
		{
			GLenum type = (*nameIter)->m_type;
			//Set value to uniform value
			switch (type)
			{
			case GL_INT:
			{
				int v = *(static_cast<int*>(value));
				UniformInt* newUni = dynamic_cast<UniformInt*>((*nameIter));
				newUni->m_value = v;
				glUseProgram(m_shaderProgram->m_programID);
				newUni->BindUniform();
				isFound = true;
				break;
			}
				
			case GL_FLOAT:
			{
				float v = *(static_cast<float*>(value));
				UniformFloat* newUni = dynamic_cast<UniformFloat*>((*nameIter));
				newUni->m_value = v;
				glUseProgram(m_shaderProgram->m_programID);
				newUni->BindUniform();
				isFound = true;
				break;
			}
				
			case GL_FLOAT_VEC3:
			{
				Vector3 v = *(static_cast<Vector3*>(value));
				UniformVec3* newUni = dynamic_cast<UniformVec3*>((*nameIter));
				newUni->m_value = v;
				glUseProgram(m_shaderProgram->m_programID);
				newUni->BindUniform();
				isFound = true;
				break;
			}
				
			case GL_FLOAT_VEC4:
			{
				Vector4 v = *(static_cast<Vector4*>(value));
				UniformVec4* newUni = dynamic_cast<UniformVec4*>((*nameIter));
				newUni->m_value = v;
				glUseProgram(m_shaderProgram->m_programID);
				newUni->BindUniform();
				isFound = true;
				break;
			}
				
			case GL_FLOAT_MAT4:
			{
				mat44_fl v = *(static_cast<mat44_fl*>(value));
				UniformMat4* newUni = dynamic_cast<UniformMat4*>((*nameIter));
				newUni->m_value = v;
				glUseProgram(m_shaderProgram->m_programID);
				newUni->BindUniform();
				isFound = true;
				break;
			}
			case GL_SAMPLER_2D:
			{
				int v = *(static_cast<int*>(value));
				UniformInt* newUni = dynamic_cast<UniformInt*>((*nameIter));
				newUni->m_value = v;
				glUseProgram(m_shaderProgram->m_programID);
				newUni->BindUniform();
				isFound = true;
				break;
			}
				
			default:
				break;
			}

			break;
		}
	}
	if (!isFound)
	{
		DebuggerPrintf("%s not found.\n", name.c_str());
	}
	//Maybe typecast before setting?
}

void Material::SetAttribute(std::string name)
{
	for (auto nameIter = m_attributes.begin(); nameIter != m_attributes.end(); ++nameIter)
	{
		std::string attribName = (*nameIter)->m_name;
		if (attribName == name)
		{
			GLenum type = (*nameIter)->m_type;
			switch (type)
			{
				case GL_FLOAT_VEC2:
				{
					AttributeVec2* newAtrib = dynamic_cast<AttributeVec2*>((*nameIter));
					glUseProgram(m_shaderProgram->m_programID);
					newAtrib->BindAttribute();
					break;
				}
				case GL_FLOAT_VEC3:
				{
					AttributeVec3* newAtrib = dynamic_cast<AttributeVec3*>((*nameIter));
					glUseProgram(m_shaderProgram->m_programID);
					newAtrib->BindAttribute();
					break;
				}
				case GL_FLOAT_VEC4:
				{
					AttributeVec4* newAtrib = dynamic_cast<AttributeVec4*>((*nameIter));
					glUseProgram(m_shaderProgram->m_programID);
					newAtrib->BindAttribute();
					break;
				}
				default:
					break;
			}
			break;
		}
	}
}

void Material::SetAttribute(std::string name, GLsizei stride,
	const GLvoid * pointer)
{
	for (auto nameIter = m_attributes.begin(); nameIter != m_attributes.end(); ++nameIter)
	{
		std::string attribName = (*nameIter)->m_name;
		if (attribName == name)
		{
			GLenum type = (*nameIter)->m_type;
			switch (type)
			{
			case GL_FLOAT_VEC2:
			{
				AttributeVec2* newAtrib = dynamic_cast<AttributeVec2*>((*nameIter));
				glUseProgram(m_shaderProgram->m_programID);
				if (newAtrib->m_location >= 0)
				{
					glEnableVertexAttribArray(newAtrib->m_location);
					glVertexAttribPointer(newAtrib->m_location, 2, GL_FLOAT, GL_FALSE, stride, pointer);

				}
				break;
			}
			case GL_FLOAT_VEC3:
			{
				AttributeVec3* newAtrib = dynamic_cast<AttributeVec3*>((*nameIter));
				glUseProgram(m_shaderProgram->m_programID);
				if (newAtrib->m_location >= 0)
				{
					glEnableVertexAttribArray(newAtrib->m_location);
					glVertexAttribPointer(newAtrib->m_location, 3, GL_FLOAT, GL_FALSE, stride, pointer);

				}
				break;
			}
			case GL_FLOAT_VEC4:
			{
				AttributeVec4* newAtrib = dynamic_cast<AttributeVec4*>((*nameIter));
				glUseProgram(m_shaderProgram->m_programID);
				if (newAtrib->m_location >= 0)
				{
					glEnableVertexAttribArray(newAtrib->m_location);
					glVertexAttribPointer(newAtrib->m_location, 4, GL_UNSIGNED_BYTE, GL_TRUE, stride, pointer);

				}
				break;
			}
			default:
				break;
			}
			break;
		}
	}
}

GLuint Material::CreateSampler(GLenum min_filter, GLenum mag_filter, GLenum u_wrap, GLenum v_wrap)
{
	GLuint id;
	glGenSamplers(1, &id);

	glSamplerParameteri(id, GL_TEXTURE_MIN_FILTER, min_filter);
	glSamplerParameteri(id, GL_TEXTURE_MAG_FILTER, mag_filter);
	glSamplerParameteri(id, GL_TEXTURE_WRAP_S, u_wrap);
	glSamplerParameteri(id, GL_TEXTURE_WRAP_T, v_wrap);

	return id;
}

void Material::BindTextures()
{
	int textureIndex = 0;
	for (auto nameIter = m_uniforms.begin(); nameIter != m_uniforms.end(); ++nameIter)
	{
		GLenum type = (*nameIter)->m_type;

		if (type == GL_SAMPLER_2D)
		{
			UniformInt* newUni = dynamic_cast<UniformInt*>((*nameIter));

			glActiveTexture(GL_TEXTURE0 + textureIndex);
			glBindTexture(GL_TEXTURE_2D, m_texIDs[textureIndex]);
			glBindSampler(textureIndex, m_samplerID);
			newUni->m_value = textureIndex;
			newUni->BindUniform();
			textureIndex++;
		}
	}

}

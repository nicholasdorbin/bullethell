#pragma once

#include <vector>

#include "Engine/Renderer/VertexPCT.hpp"
#include "Engine/Renderer/VertexPCUTB.hpp"
#include "Engine/Renderer/OpenGLExtensions.hpp"
class Material;


//-----------------------------------------------------------------------------------------------
class Mesh
{
public:
	Mesh();
	void MakeCubeMesh();
	void MakeSphereMesh();
	void MakeTangentQuad();
	void MakeTangentCubeMesh();
	void MakeTangentSphereMesh();

	GLuint BufferCreate(void *data, size_t count, size_t elem_size, GLenum usage);

	void BindAttributeToMat(Material* mat, std::string name, GLsizei stride, const GLvoid * pointer);
	void BindWithMaterial(Material* mat);
	void BindWithMaterialTangent(Material* mat);
	void DrawWithMaterial(Material* mat);
public:
	std::vector< Vertex3D_PCT > m_verts;
	std::vector< Vertex3D_PCUTB > m_tangentVerts;
	std::vector< uint16_t > m_indices;

	GLuint m_VAO;
	GLuint m_VBO;
	GLuint m_IBO;
};
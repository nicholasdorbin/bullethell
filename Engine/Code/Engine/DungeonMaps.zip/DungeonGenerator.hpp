#pragma once
#include "Game/Generators/Generator.hpp"
#include <vector>

class IntAABB2;
class IntVector2;
class Map;
class Cell;

enum CellDirection
{
	CELLDIRECTION_NORTH = 0,
	CELLDIRECTION_SOUTH,
	CELLDIRECTION_EAST,
	CELLDIRECTION_WEST,

};

struct AjacentCells
{
	CellDirection m_direction;
	IntVector2 m_position;
};

class DungeonGenerator : public Generator
{
public:
	
	DungeonGenerator(std::string name) :Generator(name) {};

	static Generator* CreateGenerator(const std::string& name) { return new DungeonGenerator(name); };
	virtual Map* CreateInitializedMap(const IntVector2& size, const std::string& name = "TESTMAP");
	virtual bool GenerateStep(Map* map, int currentStepNumber);

	static GeneratorRegistration s_DungeonGeneratorRegistration;

private:
	std::vector<Cell> m_borderCells;
	IntVector2 m_startPosition;
	CellDirection m_direction;

	int m_roomWidth;
	int m_roomHeight;

	int m_hallwayLengthMin;
	int m_hallwayLengthMax;

	bool AttemptToMakeRoom(Map* map, IntVector2 startPos);
	IntAABB2 CreateRoom(Map* map, IntVector2 startPos);
	bool AttemptToMakeHallway(Map* map, IntVector2* startPos);
	IntAABB2 const MakeHallway(IntVector2 * const out_buildOrigin);
	std::vector < AjacentCells > GetAirCellsNextToWall(Map* map);
};
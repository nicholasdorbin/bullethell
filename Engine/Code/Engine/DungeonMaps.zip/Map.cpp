#include "Game/Maps/Map.hpp"

#include "Engine/Renderer/Renderer.hpp"
#include "Engine/Math/Vector2.hpp"
#include "Engine/Math/IntVector2.hpp"

void Map::Update()
{
	for (auto mapIter = m_grid.begin(); mapIter != m_grid.end(); ++mapIter)
	{
		if (mapIter->m_nextType != CELLTYPE_INVALID)
			mapIter->m_currentType = mapIter->m_nextType;
	}
}

void Map::Render() const
{
	static BitmapFont* fixedFont = BitmapFont::CreateOrGetFont("SquirrelFixedFont.png");
	float xOffset = (80.0f - m_width) * 10.0f;
	float yOffset = (45.0f - m_height) * 10.0f;
	Vector2 bottomLeftOffset(xOffset, yOffset);
	// Draw the cells
	int cellIndex = 0;
	for (cellIndex = 0; cellIndex < m_grid.size(); cellIndex++)
	{
		Cell currentCell = m_grid[cellIndex];
		IntVector2 currentCellPosition = currentCell.m_position;

		Vector2 cellPosition((float)currentCellPosition.x * 20.0f, (float)currentCellPosition.y * 20.0f);

		if (m_grid[cellIndex].m_currentType == CELLTYPE_AIR)
		{
			g_theRenderer->DrawText2D(bottomLeftOffset + cellPosition, ".", 15.0f, Rgba::WHITE, fixedFont);
		}
		else if (m_grid[cellIndex].m_currentType == CELLTYPE_STONE)
		{
			g_theRenderer->DrawText2D(bottomLeftOffset + cellPosition, "X", 15.0f, Rgba::LTGRAY, fixedFont);
		}
	}
}

int Map::GetIndexForPosition(int cellX, int cellY)
{
	//return (m_width * cellY) + cellX;
	return cellY * m_width + cellX;
}

int Map::GetIndexForPosition(IntVector2 position)
{
	int cellX = position.x;
	int cellY = position.y;
	return (m_width * cellY) + cellX;
}

std::vector<Cell> Map::GetNeighborsInRange(IntVector2 position, int range)
{
	std::vector<Cell> output;
	for (int x = position.x - range; x <= position.x + range; x++)
	{
		for (int y = position.y - range; y <= position.y + range; y++)
		{
			Cell thisCell = GetCellAtPosition(IntVector2(x, y));
			if (IsPositionValid(thisCell.m_position) && thisCell.m_position != position)
			{
				output.push_back(thisCell);
			}
		}
	}
	return output;
}

std::vector<Cell> Map::GetNeighborsInRangeOfType(IntVector2 position, int range, CellType type)
{
	std::vector<Cell> output;
	for (int x = position.x - range; x <= position.x + range; x++)
	{
		for (int y = position.y - range; y <= position.y + range; y++)
		{
			Cell thisCell = GetCellAtPosition(IntVector2(x, y));
			if (IsPositionValid(thisCell.m_position) && thisCell.m_position != position && thisCell.m_currentType == type)
			{
				output.push_back(thisCell);
			}
		}
	}
	return output;
}

Cell Map::GetCellAtPosition(IntVector2 position)
{
	if (IsPositionValid(position))
	{
		int index = GetIndexForPosition(position.x, position.y);
		return m_grid[index];
	}
	//#TODO Find a better else case
	return Cell();
}

CellType Map::GetTypeAt(int cellX, int cellY)
{
	if (IsPositionValid(cellX, cellY))
	{
		int index = GetIndexForPosition(cellX, cellY);
		return m_grid[index].m_currentType;
	}
	return CELLTYPE_INVALID;
}

bool Map::IsCellValid(Cell cell)
{
	return IsPositionValid(cell.m_position);
}

bool Map::IsPositionValid(IntVector2 position)
{
	if (position.x >= m_width || position.x < 0)
		return false;
	if (position.y >= m_height || position.y < 0)
		return false;
	return true;
}


bool Map::IsPositionValid(int cellX, int cellY)
{
	IntVector2 pos = IntVector2(cellX, cellY);
	return IsPositionValid(pos);
}

bool Map::IsAreaValid(IntAABB2 area)
{
	if (area.m_mins.x >= m_width || area.m_mins.x < 0
		|| area.m_maxs.x >= m_width || area.m_maxs.x < 0)
		return false;
	if (area.m_mins.y >= m_width || area.m_mins.y < 0
		|| area.m_maxs.y >= m_width || area.m_maxs.y < 0)
		return false;
	return true;
}

bool Map::IsAreaContainsType(IntAABB2 area, CellType type)
{
	bool containsType = false;
	for (int y = area.m_mins.y; y <= area.m_maxs.y; y++)
	{
		for (int x = area.m_mins.x; x <= area.m_maxs.x; x++)
		{
			Cell thisCell = GetCellAtPosition(IntVector2(x, y));
			//If cell is invalid, continue
			if (IsCellValid(thisCell))
			{
				if (IsCellOfType(thisCell, type))
					containsType = true;
			}
			else
			{
				continue;
			}
		}
	}
	return containsType;
}

void Map::SetCellAsType(Cell cell, CellType type)
{
	if (IsCellValid(cell))
	{
		int index = GetIndexForPosition(cell.m_position);
		SetCellAsTypeAtIndex(index, type);
	}
}

void Map::SetCellAsTypeAtIndex(int index, CellType type )
{
	m_grid[index].m_currentType = type;
}

void Map::SetAreaAsType(IntAABB2 area, CellType type)
{
	for (int y = area.m_mins.y; y <= area.m_maxs.y; y++)
	{
		for (int x = area.m_mins.x; x <= area.m_maxs.x; x++)
		{
			Cell thisCell = GetCellAtPosition(IntVector2(x, y));
			//If cell is invalid, continue
			if (IsCellValid(thisCell))
			{
				SetCellAsType(thisCell, type);
			}
			else
			{
				continue;
			}
		}
	}
}

bool Map::IsCellOfType(Cell cell, CellType type)
{
	if (IsCellValid(cell))
	{
		return (cell.m_currentType == type);
	}
	return false;
}

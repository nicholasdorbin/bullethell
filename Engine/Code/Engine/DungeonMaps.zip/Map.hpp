#pragma once
#include "Game/Cells/Cell.hpp"
#include <vector>
#include "Engine/Math/IntVector2.hpp"
#include "Engine/Math/IntAABB2.hpp"


class Map
{
public:
	int m_width;
	int m_height;
	std::vector<Cell> m_grid;
	void Update();
	void Render() const;

	int GetIndexForPosition(int cellX, int cellY);
	int GetIndexForPosition(IntVector2 position);

	std::vector<Cell> GetNeighborsInRange(IntVector2 position, int range);
	std::vector<Cell> GetNeighborsInRangeOfType(IntVector2 position, int range, CellType type);
	Cell GetCellAtPosition(IntVector2 position);
	CellType GetTypeAt(int cellX, int cellY);
	bool IsCellValid(Cell cell);
	bool IsPositionValid(int cellX, int cellY);
	bool IsPositionValid(IntVector2 position);
	bool IsAreaValid(IntAABB2 area);
	bool IsAreaContainsType(IntAABB2 area, CellType type);
	void SetCellAsType(Cell cell, CellType type);
	void SetCellAsTypeAtIndex(int index, CellType type);
	void SetAreaAsType(IntAABB2 area, CellType type);
	bool IsCellOfType(Cell cell, CellType type);
};
#include "Game/Generators/DungeonGenerator.hpp"
#include "Game/Maps/Map.hpp"
#include "Game/Environments/EnvironmentGenerationProcess.hpp"
#include "Engine/MathUtils.hpp"
#include "Engine/Math/IntVector2.hpp"
#include "Engine/Math/IntAABB2.hpp"
#include <vector>

Map* DungeonGenerator::CreateInitializedMap(const IntVector2& size, const std::string& name /*= "TESTMAP"*/)
{
	Map* newMap = new Map();
	for (int y = 0; y < size.y; y++)
	{
		for (int x = 0; x < size.x; x++)
		{

			newMap->m_grid.push_back(Cell(IntVector2(x, y), CELLTYPE_STONE));

		}
	}
	newMap->m_width = size.x;
	newMap->m_height = size.y;
	m_roomWidth = RandomInt(6, 3);
	m_roomHeight = RandomInt(6, 3);
	m_hallwayLengthMin = 3;
	m_hallwayLengthMax = 10;


	m_startPosition = IntVector2(RandomInt(size.x - 4) + 2, RandomInt(size.y - 4) + 2);
	m_direction = (CellDirection)RandomInt(4);
	AttemptToMakeRoom(newMap, m_startPosition);
	//newMap->Update();
	return newMap;
}

bool DungeonGenerator::GenerateStep(Map* map, int currentStepNumber)
{
	
	//Find all empty air tiles next to a wall
	std::vector < AjacentCells > freeCells = GetAirCellsNextToWall(map);

	if (freeCells.size() > 0)
	{
		int randomIndex = RandomInt((int)freeCells.size());
		m_direction = freeCells[randomIndex].m_direction;
		IntVector2 buildOrigin = freeCells[randomIndex].m_position;

		//AttempMakeHall
		if (AttemptToMakeHallway(map, &buildOrigin))
		{
			AttemptToMakeRoom(map, buildOrigin);
		}
	}
	AttemptToMakeRoom(map, m_startPosition );
	
	//map->Update();
	return true;
}

GeneratorRegistration DungeonGenerator::s_DungeonGeneratorRegistration("DungeonGen", &DungeonGenerator::CreateGenerator, &Generator::CreateEnvironmentGenerationProcess);

bool DungeonGenerator::AttemptToMakeRoom(Map* map, IntVector2 startPos )
{
	IntAABB2 room = CreateRoom(map, startPos);

	if (map->IsAreaContainsType(room, CellType::CELLTYPE_AIR))
	{
		return false;
	}
	else
	{
		map->SetAreaAsType(room, CELLTYPE_AIR);
	}
}

IntAABB2 DungeonGenerator::CreateRoom(Map* map, IntVector2 startPos)
{
	m_roomWidth = RandomInt(6, 3);
	m_roomHeight = RandomInt(6, 3);
	IntAABB2 room;
	switch (m_direction)
	{
	case CellDirection::CELLDIRECTION_NORTH:
	{


		int minsX = startPos.x - m_roomWidth;
		int minsY = startPos.y;

		int maxX = minsX + m_roomWidth;
		int maxY = startPos.y + m_roomHeight;
		room = IntAABB2(IntVector2(minsX, minsY), IntVector2(maxX, maxY));

		return room;

		break;
	}
	case CellDirection::CELLDIRECTION_SOUTH:
	{
		int xMin = startPos.x - RandomInt(m_roomWidth);
		int xMax = xMin + m_roomWidth - 1;
		int yMax = startPos.y;
		int yMin = yMax - m_roomHeight + 1;
		return IntAABB2(IntVector2(xMin, yMin), IntVector2(xMax, yMax));
		break;
	}
	case CellDirection::CELLDIRECTION_EAST:
	{
		int xMin = startPos.x;
		int xMax = xMin + m_roomWidth - 1;
		int yMin = startPos.y - RandomInt(m_roomHeight);
		int yMax = yMin + m_roomHeight - 1;
		return IntAABB2(IntVector2(xMin, yMin), IntVector2(xMax, yMax));
		break;
	}
	case CellDirection::CELLDIRECTION_WEST:
	{
		int xMax = startPos.x;
		int xMin = xMax - m_roomWidth + 1;
		int yMin = startPos.y - RandomInt(m_roomHeight);
		int yMax = yMin + m_roomHeight - 1;
		return IntAABB2(IntVector2(xMin, yMin), IntVector2(xMax, yMax));
		break;
	}
	default:
		break;
	}
	
}

bool DungeonGenerator::AttemptToMakeHallway(Map* map, IntVector2* outPos)
{
	IntAABB2 const hallArea = MakeHallway(outPos);

	//if(Check room area (and border))
	if (map->IsAreaContainsType(hallArea, CELLTYPE_STONE))
	{
		//StampRoom
		map->SetAreaAsType(hallArea, CELLTYPE_AIR);

		if (map->IsPositionValid(outPos->x, outPos->y))
		{
			return true;
		}
		else
		{
			return false;
		}
	}
	//else
	else
	{
		//NoHallMade
		return false;
	}
}

//-------------------------------------------------------------------------------------------------
IntAABB2 const DungeonGenerator::MakeHallway(IntVector2 * const out_buildOrigin)
{
	//#TODO: Maybe do hall size checks
	int length = RandomInt(11, 3);

	switch (m_direction)
	{
	case CELLDIRECTION_NORTH:
	{
		int xMin = out_buildOrigin->x;
		int xMax = xMin;
		int yMin = out_buildOrigin->y + 1;
		int yMax = yMin + length;
		*out_buildOrigin = IntVector2(xMax, yMax + 1);
		return IntAABB2(IntVector2(xMin, yMin), IntVector2(xMax, yMax));
		break;
	}
	case CELLDIRECTION_SOUTH:
	{
		int xMin = out_buildOrigin->x;
		int xMax = xMin;
		int yMax = out_buildOrigin->y - 1;
		int yMin = yMax - length;
		*out_buildOrigin = IntVector2(xMin, yMin - 1);
		return IntAABB2(IntVector2(xMin, yMin), IntVector2(xMax, yMax));
		break;
	}
	case CELLDIRECTION_EAST:
	{
		int xMin = out_buildOrigin->x + 1;
		int xMax = xMin + length;
		int yMin = out_buildOrigin->y;
		int yMax = yMin;
		*out_buildOrigin = IntVector2(xMax + 1, yMax);
		return IntAABB2(IntVector2(xMin, yMin), IntVector2(xMax, yMax));
		break;
	}
	case CELLDIRECTION_WEST:
	{
		int xMax = out_buildOrigin->x - 1;
		int xMin = xMax - length;
		int yMax = out_buildOrigin->y;
		int yMin = yMax;
		*out_buildOrigin = IntVector2(xMin - 1, yMin);
		return IntAABB2(IntVector2(xMin, yMin), IntVector2(xMax, yMax));
		break;
	}
	default:
	{
		break;
	}
	}
}

std::vector < AjacentCells > DungeonGenerator::GetAirCellsNextToWall(Map* map)
{
	AjacentCells foundTile;
	std::vector<AjacentCells> result;

	for (int yIndex = 0; yIndex < map->m_height; ++yIndex)
	{
		for (int xIndex = 0; xIndex < map->m_width; ++xIndex)
		{
			foundTile.m_position = IntVector2(xIndex, yIndex);
			if (map->GetTypeAt(xIndex, yIndex) == CELLTYPE_AIR)
			{
				//Check North
				if (map->IsPositionValid(IntVector2(xIndex, yIndex + 1)) && map->GetTypeAt(xIndex, yIndex + 1) == CELLTYPE_STONE)
				{
					foundTile.m_direction = CELLDIRECTION_NORTH;
					result.push_back(foundTile);
				}

				//Check South
				if (map->IsPositionValid(xIndex, yIndex - 1) && map->GetTypeAt(xIndex, yIndex - 1) == CELLTYPE_STONE)
				{
					foundTile.m_direction = CELLDIRECTION_SOUTH;
					result.push_back(foundTile);
				}

				//Check East
				if (map->IsPositionValid(xIndex + 1, yIndex) && map->GetTypeAt(xIndex + 1, yIndex) == CELLTYPE_STONE)
				{
					foundTile.m_direction = CELLDIRECTION_EAST;
					result.push_back(foundTile);
				}

				//Check West
				if (map->IsPositionValid(xIndex - 1, yIndex) && map->GetTypeAt(xIndex - 1, yIndex) == CELLTYPE_STONE)
				{
					foundTile.m_direction = CELLDIRECTION_WEST;
					result.push_back(foundTile);
				}
			}
		}
	}

	return result;
}
